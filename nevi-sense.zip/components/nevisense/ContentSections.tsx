"use client";
import React, { useRef, useState, useEffect } from "react";
import RevealText, { RevealLine } from "./RevealText";
import { useScrollReveal } from "./useScrollReveal";
import BrainCanvas from "./BrainCanvas";
import ChallengeVisual from "./ChallengeVisual";
import IndependenceVisual from "./IndependenceVisual";

const FONT = "'Inter', system-ui, -apple-system, sans-serif";
const RED = "#C41E3A";

// ==========================================
// CHALLENGE SECTION
// ==========================================
export function ChallengeSection() {
  return (
    <section
      id="challenge"
      className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center"
      style={{
        backgroundColor: "#FAFAF9",
        padding: "clamp(40px, 6vw, 80px) clamp(16px, 6vw, 120px)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Background Canvas: Entire section background */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          zIndex: 0,
          pointerEvents: "none",
        }}
      >
        <ChallengeVisual />
      </div>

      {/* Left: Text content */}
      <div className="w-full max-w-[540px]" style={{ position: "relative", zIndex: 1 }}>
        <RevealText delay={0}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 12,
              marginBottom: "clamp(16px, 3vw, 32px)",
            }}
          >
            <div style={{ width: 28, height: 1, backgroundColor: RED }} />
            <span
              style={{
                fontSize: 11,
                letterSpacing: "0.25em",
                textTransform: "uppercase",
                color: RED,
                fontWeight: 500,
                fontFamily: FONT,
              }}
            >
              The Challenge
            </span>
          </div>
        </RevealText>


        {/* Stats */}
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            flexWrap: "wrap",
            gap: "clamp(24px, 4vw, 48px)",
            marginTop: "clamp(40px, 6vw, 80px)",
            width: "100%",
          }}
        >
          {[
            { num: "700M+", label: "people living with a form of visual impairment" },
            { num: "3m", label: "real-time scanning warnings on obstacles ahead" },
            { num: "∞", label: "journeys that deserve confidence" },
          ].map((stat, i) => (
            <RevealText
              key={i}
              delay={i * 0.1}
              style={{
                flex: "1 1 140px",
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-start",
                gap: "clamp(8px, 1.5vw, 12px)",
                borderLeft: i > 0 ? "1px solid rgba(0,0,0,0.08)" : "none",
                paddingLeft: i > 0 ? "clamp(16px, 2.5vw, 32px)" : "0",
              }}
            >
              <div
                style={{
                  fontSize: "clamp(40px, 5vw, 60px)",
                  fontWeight: 200,
                  color: "#0A0A0A",
                  fontFamily: FONT,
                  letterSpacing: "-0.03em",
                  lineHeight: 1,
                }}
              >
                {stat.num}
              </div>
              <div
                style={{
                  fontSize: "clamp(12px, 0.9vw, 14px)",
                  color: "#44403C",
                  fontFamily: FONT,
                  lineHeight: 1.4,
                  letterSpacing: "0.01em",
                  fontWeight: 300,
                }}
              >
                {stat.label}
              </div>
            </RevealText>
          ))}
        </div>
      </div>
    </section>
  );
}

// ==========================================
// WHAT IT DOES SECTION
// ==========================================
interface FeatureRowProps {
  item: {
    num: string;
    title: string;
    body: string;
  };
  index: number;
}

function FeatureRow({ item, index }: FeatureRowProps) {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });
  return (
    <div
      ref={ref}
      className="grid grid-cols-1 md:grid-cols-[80px_1fr] lg:grid-cols-[80px_1fr_1fr] gap-4 md:gap-8 items-start"
      style={{
        borderTop: "1px solid rgba(255,255,255,0.07)",
        padding: "clamp(24px, 3.5vw, 48px) 0",
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? "translateY(0)" : "translateY(24px)",
        transition: `opacity 0.9s ease ${index * 0.08}s, transform 0.9s cubic-bezier(0.76,0,0.24,1) ${index * 0.08}s`,
      }}
    >
      <div
        className="md:col-start-1"
        style={{
          fontSize: 11,
          color: RED,
          fontFamily: FONT,
          letterSpacing: "0.1em",
          paddingTop: 4,
        }}
      >
        {item.num}
      </div>
      <div
        className="md:col-start-2"
        style={{
          fontSize: "clamp(16px, 1.8vw, 22px)",
          fontWeight: 300,
          color: "#FFFFFF",
          fontFamily: FONT,
          letterSpacing: "-0.01em",
          lineHeight: 1.35,
        }}
      >
        {item.title}
      </div>
      <div
        className="md:col-start-2 lg:col-start-3"
        style={{
          fontSize: "clamp(13px, 1.1vw, 14px)",
          color: "rgba(255,255,255,0.45)",
          fontFamily: FONT,
          lineHeight: 1.7,
          fontWeight: 300,
        }}
      >
        {item.body}
      </div>
    </div>
  );
}

export function WhatItDoesSection() {
  const items = [
    {
      num: "01",
      title: "Real-time obstacle detection up to 3 meters ahead",
      body: "Active sensing gives early warning of potential hazards ahead, allowing safe, uninterrupted pacing in complicated settings.",
    },
    {
      num: "02",
      title: "Intelligent haptic feedback for intuitive navigation",
      body: "Translates invisible spatial vectors into subtle tactile stimulation, guiding step selection organically and privately.",
    },
    {
      num: "03",
      title: "Environmental awareness through multi-sensor fusion",
      body: "Merges raw peripheral signals into actionable orientation feedback, creating reliable boundaries for crowded conditions.",
    },
    {
      num: "04",
      title: "Personalized learning through behavioral and location analysis",
      body: "Adapts guidance metrics intelligently as the platform understands daily routes, speed fluctuations, and individual habits.",
    },
    {
      num: "05",
      title: "Smartphone connectivity for advanced insights and accessibility",
      body: "Provides custom user adjustments, wireless sync of historical metrics, and cloud accessibility profiles.",
    },
    {
      num: "06",
      title: "Emergency assistance and safety monitoring",
      body: "Active safety companion triggers automated assistance contact warnings when stability anomalies or fall states occur.",
    },
  ];

  return (
    <section
      id="features"
      style={{
        backgroundColor: "#0A0A0A",
        padding: "clamp(60px, 10vw, 160px) clamp(16px, 6vw, 120px)",
      }}
    >
      <RevealText delay={0}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            marginBottom: "clamp(40px, 6vw, 80px)",
          }}
        >
          <div style={{ width: 28, height: 1, backgroundColor: RED }} />
          <span
            style={{
              fontSize: 11,
              letterSpacing: "0.25em",
              textTransform: "uppercase",
              color: RED,
              fontWeight: 500,
              fontFamily: FONT,
            }}
          >
            Platform
          </span>
        </div>
      </RevealText>

      <RevealLine delay={0}>
        <h2
          style={{
            margin: "0 0 24px 0",
            fontFamily: FONT,
            fontWeight: 200,
            fontSize: "clamp(28px, 4.5vw, 64px)",
            letterSpacing: "-0.03em",
            color: "#FFFFFF",
            lineHeight: 1.15,
            maxWidth: 700,
          }}
        >
          Continuous awareness.
          <br />
          Intuitive guidance.
        </h2>
      </RevealLine>

      <RevealText delay={0.1}>
        <p
          style={{
            margin: "0 0 clamp(40px, 6vw, 80px) 0",
            fontFamily: FONT,
            fontSize: "clamp(16px, 1.3vw, 20px)",
            fontWeight: 300,
            lineHeight: 1.6,
            color: "rgba(255,255,255,0.7)",
            maxWidth: 800,
          }}
        >
          NEVISENSE combines advanced sensing, wearable technology, mobile intelligence, and adaptive software into a single assistive ecosystem.
        </p>
      </RevealText>

      <div style={{ display: "flex", flexDirection: "column", gap: 0, marginBottom: "clamp(48px, 6vw, 80px)" }}>
        {items.map((item, i) => (
          <FeatureRow key={i} item={item} index={i} />
        ))}
      </div>

      <RevealText delay={0.2}>
        <p
          style={{
            margin: 0,
            fontFamily: FONT,
            fontSize: "clamp(15px, 1.2vw, 17px)",
            fontWeight: 300,
            lineHeight: 1.65,
            color: "rgba(255,255,255,0.6)",
            maxWidth: 680,
            borderLeft: `2px solid ${RED}`,
            paddingLeft: 24,
          }}
        >
          Designed as a lightweight wearable device, NEVISENSE seamlessly integrates into everyday life while continuously supporting user mobility.
        </p>
      </RevealText>
    </section>
  );
}

// ==========================================
// REIMAGINING INDEPENDENCE SECTION
// ==========================================
export function IndependenceSection() {
  const { ref, progress } = useScrollReveal({ threshold: 0 });
  const bgOpacity = Math.min(progress * 1.5, 1);

  // Map progress to rgb transition from stone off-white (#FAFAF9 / 250,250,249) to dark off-black (#080808 / 8,8,8)
  const currentR = Math.round(250 - bgOpacity * 242);
  const currentG = Math.round(250 - bgOpacity * 242);
  const currentB = Math.round(249 - bgOpacity * 241);

  return (
    <section
      ref={ref}
      style={{
        position: "relative",
        backgroundColor: `rgb(${currentR}, ${currentG}, ${currentB})`,
        transition: "background-color 0.1s linear",
        overflow: "hidden",
      }}
    >
      {/* Background Canvas: Entire section background */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          zIndex: 0,
          pointerEvents: "none",
        }}
      >
        <IndependenceVisual lightMode={bgOpacity < 0.5} />
      </div>

      {/* Grid wrapper so that text grid columns align correctly and stay visible */}
      <div
        className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center"
        style={{
          position: "relative",
          zIndex: 1,
          padding: "clamp(40px, 6vw, 80px) clamp(16px, 6vw, 120px)",
        }}
      >
        {/* Left: Text content */}
        <div className="w-full max-w-[540px]">
        <RevealText delay={0}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 12,
              marginBottom: "clamp(16px, 3vw, 32px)",
            }}
          >
            <div
              style={{
                width: 28,
                height: 1,
                backgroundColor: bgOpacity > 0.5 ? "#fff" : RED,
              }}
            />
            <span
              style={{
                fontSize: 11,
                letterSpacing: "0.25em",
                textTransform: "uppercase",
                color: bgOpacity > 0.5 ? "rgba(255,255,255,0.5)" : RED,
                fontWeight: 500,
                fontFamily: FONT,
                transition: "color 0.3s ease",
              }}
            >
              Reimagining Independence
            </span>
          </div>
        </RevealText>
        
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <RevealLine delay={0.05}>
            <p
              style={{
                margin: 0,
                fontFamily: FONT,
                fontSize: "clamp(15px, 1.2vw, 17px)",
                fontWeight: 300,
                lineHeight: 1.65,
                color: bgOpacity > 0.5 ? "#FFFFFF" : "#0A0A0A",
                transition: "color 0.3s ease",
              }}
            >
              We believe independence is not simply the ability to move—it&apos;s the freedom to explore, work, travel, and live confidently.
            </p>
          </RevealLine>
          <RevealLine delay={0.1}>
            <p
              style={{
                margin: 0,
                fontFamily: FONT,
                fontSize: "clamp(15px, 1.2vw, 17px)",
                fontWeight: 300,
                lineHeight: 1.65,
                color: bgOpacity > 0.5 ? "rgba(255,255,255,0.85)" : "#292524",
                transition: "color 0.3s ease",
              }}
            >
              NEVISENSE reimagines mobility through intelligent sensing, adaptive feedback, and continuous learning.
            </p>
          </RevealLine>
          <RevealLine delay={0.15}>
            <p
              style={{
                margin: 0,
                fontFamily: FONT,
                fontSize: "clamp(15px, 1.2vw, 17px)",
                fontWeight: 300,
                lineHeight: 1.65,
                color: bgOpacity > 0.5 ? "rgba(255,255,255,0.85)" : "#292524",
                transition: "color 0.3s ease",
              }}
            >
              By transforming invisible environmental information into intuitive sensory guidance, we empower users to navigate the world with greater awareness and confidence.
            </p>
          </RevealLine>
          <RevealLine delay={0.2}>
            <p
              style={{
                margin: 0,
                fontFamily: FONT,
                fontSize: "clamp(14px, 1.1vw, 15px)",
                fontWeight: 500,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                color: bgOpacity > 0.5 ? "rgba(255,255,255,0.5)" : "#57534E",
                transition: "color 0.3s ease",
              }}
            >
              Our goal is simple:
            </p>
          </RevealLine>
          <RevealLine delay={0.25}>
            <p
              style={{
                margin: 0,
                fontFamily: FONT,
                fontSize: "clamp(17px, 1.5vw, 21px)",
                fontWeight: 400,
                lineHeight: 1.5,
                color: RED,
              }}
            >
              To make every step safer, smarter, and more independent.
            </p>
          </RevealLine>
        </div>
      </div>

      {/* Right: Empty spacer column to let background canvas content breathe */}
      <div className="hidden lg:block w-full min-h-[300px]" />
    </div>
  </section>
  );
}

// ==========================================
// DIGITAL BIOMARKERS SECTION
// ==========================================
export function BiomarkersSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [localProgress, setLocalProgress] = useState(0);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const onScroll = () => {
      const rect = el.getBoundingClientRect();
      const p = (window.innerHeight - rect.top) / (window.innerHeight + rect.height);
      const raw = Math.max(0, Math.min(1, p));
      // Delay brain particles disintegration starting after 45% scroll
      const delayed = raw < 0.45 ? 0 : (raw - 0.45) / 0.55;
      setLocalProgress(delayed);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const biomarkers = [
    "Walking speed and cadence",
    "Balance and gait consistency",
    "Movement confidence",
    "Environmental interaction patterns",
    "Activity levels and routine changes",
  ];

  return (
    <section
      id="biomarkers"
      ref={sectionRef}
      className="relative bg-[#080808] overflow-hidden flex flex-col lg:block min-h-screen"
    >
      {/* Brain: absolute left half */}
      <div
        className="w-full lg:w-1/2 h-[45vh] lg:h-full relative lg:absolute lg:left-0 lg:top-0 z-[1]"
      >
        <BrainCanvas scrollProgress={localProgress} />
      </div>

      {/* Content: right half */}
      <div
        className="relative z-[2] w-full lg:w-1/2 lg:ml-[50%] min-h-[55vh] lg:min-h-screen flex flex-col justify-center px-6 sm:px-12 lg:px-20 py-16 lg:py-24"
      >
        <RevealText delay={0}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 12,
              marginBottom: "clamp(24px, 4vw, 48px)",
            }}
          >
            <div style={{ width: 28, height: 1, backgroundColor: RED }} />
            <span
              style={{
                fontSize: 11,
                letterSpacing: "0.25em",
                textTransform: "uppercase",
                color: RED,
                fontWeight: 500,
                fontFamily: FONT,
              }}
            >
              Biomarkers
            </span>
          </div>
        </RevealText>

        <RevealLine delay={0.1}>
          <h2
            style={{
              margin: "0 0 24px 0",
              fontFamily: FONT,
              fontWeight: 200,
              fontSize: "clamp(32px, 5.5vw, 80px)",
              letterSpacing: "-0.04em",
              color: "#FFFFFF",
              lineHeight: 1.05,
            }}
          >
            Sensing.
            <br />
            Understanding.
          </h2>
        </RevealLine>

        <RevealText delay={0.3}>
          <p
            style={{
              fontSize: "clamp(15px, 1.2vw, 17px)",
              color: "rgba(255,255,255,0.7)",
              fontFamily: FONT,
              fontWeight: 300,
              lineHeight: 1.65,
              maxWidth: 480,
              marginTop: 24,
              marginBottom: "clamp(32px, 5vw, 56px)",
            }}
          >
            Movement patterns reveal valuable information about a person&apos;s wellbeing, safety, and daily routine.
            <br />
            <br />
            NEVISENSE analyzes mobility-related digital biomarkers such as:
          </p>
        </RevealText>

        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: 0,
            maxWidth: 500,
          }}
        >
          {biomarkers.map((b, i) => (
            <RevealText key={i} delay={0.1 + i * 0.1}>
              <div
                style={{
                  borderTop: "1px solid rgba(255,255,255,0.08)",
                  padding: "20px 0",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <span
                  style={{
                    fontSize: 15,
                    color: "rgba(255,255,255,0.85)",
                    fontFamily: FONT,
                    fontWeight: 300,
                  }}
                >
                  {b}
                </span>
                <span
                  style={{
                    fontSize: 10,
                    color: RED,
                    letterSpacing: "0.2em",
                  }}
                >
                  ✦
                </span>
              </div>
            </RevealText>
          ))}
          <div style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }} />
        </div>

        <RevealText delay={0.4}>
          <p
            style={{
              fontSize: "clamp(13px, 1.1vw, 14px)",
              color: "rgba(255,255,255,0.5)",
              fontFamily: FONT,
              fontWeight: 300,
              lineHeight: 1.7,
              maxWidth: 480,
              marginTop: 32,
              marginBottom: "clamp(24px, 4vw, 48px)",
            }}
          >
            These insights can help identify meaningful behavioral changes, support caregivers, and contribute to future health-monitoring applications while maintaining user privacy and control.
          </p>
        </RevealText>

        {/* Large active/continuous 24/7 indicator */}
        <RevealText delay={0.5}>
          <div style={{ marginTop: "clamp(20px, 4vw, 40px)" }}>
            <div
              style={{
                fontSize: 11,
                letterSpacing: "0.2em",
                color: "rgba(255,255,255,0.3)",
                fontFamily: FONT,
                textTransform: "uppercase",
                marginBottom: 8,
              }}
            >
              Continuous monitoring
            </div>
            <div
              style={{
                fontSize: "clamp(48px, 8vw, 110px)",
                fontWeight: 100,
                color: "#FFFFFF",
                fontFamily: FONT,
                letterSpacing: "-0.05em",
                lineHeight: 1,
              }}
            >
              24<span style={{ color: RED }}>/</span>7
            </div>
            <div
              style={{
                fontSize: "clamp(12px, 1vw, 14px)",
                color: "rgba(255,255,255,0.35)",
                fontFamily: FONT,
                marginTop: 12,
                fontWeight: 300,
              }}
            >
              awareness of your mobility health
            </div>
          </div>
        </RevealText>
      </div>
    </section>
  );
}

// ==========================================
// BEYOND NAVIGATION SECTION
// ==========================================
export function BeyondNavigationSection() {
  const paragraphs = [
    "Navigation is only the beginning.",
    "NeviSense is designed to understand mobility itself.",
    "The platform continuously learns from movement behavior and long-term trends.",
    "This creates a deeper understanding of how individuals interact with the world around them.",
    "The result is a system that evolves alongside the people who use it.",
  ];

  return (
    <section
      style={{
        backgroundColor: "#FAFAF9",
        padding: "clamp(60px, 10vw, 160px) clamp(16px, 6vw, 120px)",
      }}
    >
      <RevealText>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            marginBottom: "clamp(40px, 6vw, 72px)",
          }}
        >
          <div style={{ width: 28, height: 1, backgroundColor: RED }} />
          <span
            style={{
              fontSize: 11,
              letterSpacing: "0.25em",
              textTransform: "uppercase",
              color: RED,
              fontWeight: 500,
              fontFamily: FONT,
            }}
          >
            Beyond Navigation
          </span>
        </div>
      </RevealText>
      {paragraphs.map((p, i) => (
        <RevealLine key={i} delay={i * 0.08}>
          <p
            style={{
              margin: "0 0 clamp(16px, 2.5vw, 32px) 0",
              fontFamily: FONT,
              fontWeight: 200,
              fontSize: "clamp(16px, 2.5vw, 42px)",
              letterSpacing: "-0.02em",
              color: i === 0 ? "#0A0A0A" : `rgba(10,10,10,${1 - i * 0.12})`,
              lineHeight: 1.3,
            }}
          >
            {p}
          </p>
        </RevealLine>
      ))}
    </section>
  );
}

// ==========================================
// HEALTH INSIGHTS SECTION
// ==========================================
interface InsightCardProps {
  item: {
    title: string;
    desc: string;
  };
  index: number;
}

function InsightCard({ item, index }: InsightCardProps) {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });
  const [hovered, setHovered] = useState(false);

  return (
    <div
      ref={ref}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        padding: "clamp(24px, 3.5vw, 44px)",
        borderRight: "1px solid rgba(0,0,0,0.1)",
        borderBottom: "1px solid rgba(0,0,0,0.1)",
        cursor: "default",
        backgroundColor: hovered ? "#FFFFFF" : "transparent",
        transition: "background-color 0.3s ease, opacity 0.8s ease, transform 0.8s cubic-bezier(0.76,0,0.24,1)",
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? "translateY(0)" : "translateY(24px)",
        transitionProperty: "opacity, transform, background-color",
        transitionDuration: "0.8s, 0.8s, 0.3s",
        transitionDelay: `${index * 0.08}s, ${index * 0.08}s, 0s`,
      }}
    >
      <div
        style={{
          fontSize: 10,
          letterSpacing: "0.2em",
          color: RED,
          fontFamily: FONT,
          marginBottom: 20,
          textTransform: "uppercase",
        }}
      >
        0{index + 1}
      </div>
      <h3
        style={{
          margin: "0 0 16px 0",
          fontSize: "clamp(15px, 1.4vw, 19px)",
          fontWeight: 400,
          color: "#0A0A0A",
          fontFamily: FONT,
          letterSpacing: "-0.01em",
          lineHeight: 1.35,
        }}
      >
        {item.title}
      </h3>
      <p
        style={{
          margin: 0,
          fontSize: "clamp(12px, 1vw, 13px)",
          color: "#666",
          fontFamily: FONT,
          lineHeight: 1.65,
          fontWeight: 300,
        }}
      >
        {item.desc}
      </p>
    </div>
  );
}

export function HealthInsightsSection() {
  const insights = [
    {
      title: "Walking Pattern Analysis",
      desc: "Long-term trends in walking consistency, movement confidence, and mobility stability.",
    },
    {
      title: "Balance & Stability Monitoring",
      desc: "Identifying patterns that may indicate increased fall risk or changes in gait behavior.",
    },
    {
      title: "Behavioral Mobility Insights",
      desc: "Observing changes in activity levels, daily routines, and environmental engagement.",
    },
    {
      title: "Early Health Signal Detection",
      desc: "Identifying early warning signs that may support earlier intervention and better outcomes.",
    },
    {
      title: "Long-Term Health Monitoring",
      desc: "A continuous picture of mobility health tracked across weeks, months, and years.",
    },
  ];

  return (
    <section
      style={{
        backgroundColor: "#F2F1EF",
        padding: "clamp(60px, 10vw, 140px) clamp(16px, 6vw, 120px)",
      }}
    >
      <div
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-0"
        style={{
          borderTop: "1px solid rgba(0,0,0,0.1)",
        }}
      >
        {insights.map((item, i) => (
          <InsightCard key={i} item={item} index={i} />
        ))}
      </div>
    </section>
  );
}

// ==========================================
// WHO IT SERVES SECTION
// ==========================================
interface PanelCardProps {
  panel: {
    tag: string;
    title: string;
    points: string[];
  };
  index: number;
}

function PanelCard({ panel, index }: PanelCardProps) {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });
  const [hovered, setHovered] = useState(false);

  return (
    <div
      ref={ref}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        flex: "0 0 clamp(260px, 32vw, 400px)",
        scrollSnapAlign: "start",
        padding: "clamp(24px, 4vw, 48px)",
        backgroundColor: hovered ? "#1A1A1A" : "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.06)",
        cursor: "default",
        transition: "background-color 0.3s ease, opacity 0.8s ease, transform 0.8s cubic-bezier(0.76,0,0.24,1)",
        transitionDelay: `${index * 0.08}s`,
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? "translateY(0)" : "translateY(24px)",
        minHeight: 360,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
      }}
    >
      <div>
        <div
          style={{
            fontSize: 10,
            letterSpacing: "0.2em",
            color: RED,
            fontFamily: FONT,
            textTransform: "uppercase",
            marginBottom: 24,
          }}
        >
          {panel.tag}
        </div>
        <h3
          style={{
            margin: "0 0 24px 0",
            fontSize: "clamp(16px, 1.8vw, 24px)",
            fontWeight: 300,
            color: "#FFFFFF",
            fontFamily: FONT,
            letterSpacing: "-0.011em",
            lineHeight: 1.35,
          }}
        >
          {panel.title}
        </h3>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {panel.points.map((pt, j) => (
          <div
            key={j}
            style={{ display: "flex", alignItems: "center", gap: 8 }}
          >
            <div
              style={{
                width: 4,
                height: 4,
                borderRadius: "50%",
                backgroundColor: RED,
                flexShrink: 0,
              }}
            />
            <span
              style={{
                fontSize: 13,
                color: "rgba(255,255,255,0.45)",
                fontFamily: FONT,
                fontWeight: 300,
              }}
            >
              {pt}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function WhoItServesSection() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const panels = [
    {
      tag: "For Individuals",
      title: "Navigate with greater confidence and independence.",
      points: [
        "Independent navigation",
        "Increased confidence",
        "Improved situational awareness",
        "Better mobility understanding",
      ],
    },
    {
      tag: "For Families & Caregivers",
      title: "Gain meaningful long-term mobility insights.",
      points: [
        "Long-term mobility insights",
        "Awareness of behavioral changes",
        "Enhanced support planning",
        "Peace of mind",
      ],
    },
    {
      tag: "For Healthcare & Research",
      title: "Support research and mobility monitoring initiatives.",
      points: [
        "Digital biomarker generation",
        "Mobility analytics",
        "Longitudinal patient monitoring",
        "Early intervention opportunities",
      ],
    },
    {
      tag: "For Organizations & NGOs",
      title: "Deploy scalable accessibility solutions for communities.",
      points: [
        "Accessibility programs",
        "Assistive technology initiatives",
        "Community mobility support",
        "Inclusive infrastructure",
      ],
    },
  ];

  return (
    <section
      style={{
        backgroundColor: "#0A0A0A",
        padding: "clamp(60px, 8vw, 120px) 0",
        overflow: "hidden",
      }}
    >
      <RevealText delay={0}>
        <div style={{ padding: "0 clamp(16px, 6vw, 120px)", marginBottom: "clamp(32px, 5vw, 56px)" }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 12,
              marginBottom: 16,
            }}
          >
            <div style={{ width: 28, height: 1, backgroundColor: RED }} />
            <span
              style={{
                fontSize: 11,
                letterSpacing: "0.25em",
                textTransform: "uppercase",
                color: RED,
                fontWeight: 500,
                fontFamily: FONT,
              }}
            >
              Who It Serves
            </span>
          </div>
          <h2
            style={{
              margin: 0,
              fontFamily: FONT,
              fontWeight: 200,
              fontSize: "clamp(26px, 4vw, 52px)",
              letterSpacing: "-0.03em",
              color: "#FFFFFF",
              lineHeight: 1.15,
            }}
          >
            Built for everyone
            <br />
            who values independence.
          </h2>
        </div>
      </RevealText>

      <div
        ref={scrollRef}
        style={{
          display: "flex",
          overflowX: "auto",
          gap: 2,
          padding: "0 clamp(16px, 6vw, 120px) 0",
          scrollSnapType: "x mandatory",
          scrollbarWidth: "none",
        }}
      >
        {panels.map((panel, i) => (
          <PanelCard key={i} panel={panel} index={i} />
        ))}
      </div>
    </section>
  );
}

// ==========================================
// ABOUT SECTION (Mission & Profile)
// ==========================================
export function AboutSection() {
  return (
    <section
      id="about"
      style={{
        backgroundColor: "#FAFAF9",
        padding: "clamp(60px, 10vw, 160px) clamp(16px, 6vw, 120px)",
      }}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-start">
        {/* Left Column: Heading */}
        <div style={{ maxWidth: 540 }}>
          <RevealText delay={0}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                marginBottom: "clamp(24px, 4vw, 48px)",
              }}
            >
              <div style={{ width: 28, height: 1, backgroundColor: RED }} />
              <span
                style={{
                  fontSize: 11,
                  letterSpacing: "0.25em",
                  textTransform: "uppercase",
                  color: RED,
                  fontWeight: 500,
                  fontFamily: FONT,
                }}
              >
                About Us
              </span>
            </div>
          </RevealText>
          <RevealLine delay={0.1}>
            <h2
              style={{
                margin: 0,
                fontFamily: FONT,
                fontWeight: 200,
                fontSize: "clamp(28px, 4.5vw, 56px)",
                letterSpacing: "-0.03em",
                color: "#0A0A0A",
                lineHeight: 1.15,
              }}
            >
              Because independence should never be limited by visibility.
            </h2>
          </RevealLine>
        </div>

        {/* Right Column: Paragraph narrative */}
        <div style={{ display: "flex", flexDirection: "column", gap: 24, paddingLeft: "clamp(0px, 4vw, 48px)" }}>
          <RevealLine delay={0.2}>
            <p
              style={{
                margin: 0,
                fontFamily: FONT,
                fontSize: "clamp(15px, 1.2vw, 17px)",
                fontWeight: 300,
                lineHeight: 1.65,
                color: "#1C1917",
              }}
            >
              <strong>NEVISENSE</strong> is an assistive technology company focused on creating intelligent wearable solutions for accessibility and independent living.
            </p>
          </RevealLine>
          <RevealLine delay={0.3}>
            <p
              style={{
                margin: 0,
                fontFamily: FONT,
                fontSize: "clamp(15px, 1.2vw, 17px)",
                fontWeight: 300,
                lineHeight: 1.65,
                color: "#57534E",
              }}
            >
              Our mission is to empower visually impaired individuals through innovative sensing technologies, artificial intelligence, and human-centered design.
            </p>
          </RevealLine>
          <RevealLine delay={0.4}>
            <p
              style={{
                margin: 0,
                fontFamily: FONT,
                fontSize: "clamp(15px, 1.2vw, 17px)",
                fontWeight: 300,
                lineHeight: 1.65,
                color: "#57534E",
              }}
            >
              By combining advanced engineering with a deep commitment to accessibility, we are building the next generation of mobility assistance—one that learns, adapts, and grows alongside its users.
            </p>
          </RevealLine>
        </div>
      </div>
    </section>
  );
}
