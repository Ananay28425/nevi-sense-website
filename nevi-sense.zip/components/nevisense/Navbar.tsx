"use client";
import React, { useState, useEffect } from "react";
import { motion } from "motion/react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setMenuOpen(false);
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const navStyle: React.CSSProperties = {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
    padding: "0 clamp(16px, 6vw, 120px)",
    height: 64,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: scrolled ? "rgba(250,250,249,0.92)" : "transparent",
    backdropFilter: scrolled ? "blur(16px)" : "none",
    borderBottom: scrolled ? "1px solid rgba(0,0,0,0.06)" : "none",
    transition: "background-color 0.5s ease, backdrop-filter 0.5s ease, border-color 0.5s ease",
  };

  const linkStyle: React.CSSProperties = {
    fontSize: 12,
    letterSpacing: "0.12em",
    textTransform: "uppercase",
    color: "#1A1A1A",
    textDecoration: "none",
    fontWeight: 500,
    fontFamily: "'Inter', system-ui, sans-serif",
    opacity: 0.7,
    transition: "opacity 0.2s ease",
  };

  const ctaStyle: React.CSSProperties = {
    fontSize: 11,
    letterSpacing: "0.15em",
    textTransform: "uppercase",
    color: "#FFFFFF",
    backgroundColor: "#C41E3A",
    padding: "9px 20px",
    borderRadius: 2,
    textDecoration: "none",
    fontWeight: 500,
    fontFamily: "'Inter', system-ui, sans-serif",
    transition: "background-color 0.2s ease",
  };

  return (
    <>
      <nav style={navStyle}>
        <a
          href="/"
          style={{
            fontSize: 13,
            letterSpacing: "0.25em",
            textTransform: "uppercase",
            color: "#0A0A0A",
            textDecoration: "none",
            fontWeight: 600,
            fontFamily: "'Inter', system-ui, sans-serif",
            display: "inline-flex",
            alignItems: "center",
            height: "100%",
          }}
        >
          NeviSense
        </a>

        {/* Desktop/Laptop Inline Links (visible on screens >= 1024px) */}
        <div className="hidden lg:flex items-center gap-[clamp(24px,3vw,40px)]">
          <a
            href="/about"
            style={linkStyle}
            onMouseEnter={(e) => {
              (e.target as HTMLAnchorElement).style.opacity = "1";
            }}
            onMouseLeave={(e) => {
              (e.target as HTMLAnchorElement).style.opacity = "0.7";
            }}
          >
            About
          </a>
          <a
            href="/platform"
            style={linkStyle}
            onMouseEnter={(e) => {
              (e.target as HTMLAnchorElement).style.opacity = "1";
            }}
            onMouseLeave={(e) => {
              (e.target as HTMLAnchorElement).style.opacity = "0.7";
            }}
          >
            Platform
          </a>
          <a
            href="/biomarkers"
            style={linkStyle}
            onMouseEnter={(e) => {
              (e.target as HTMLAnchorElement).style.opacity = "1";
            }}
            onMouseLeave={(e) => {
              (e.target as HTMLAnchorElement).style.opacity = "0.7";
            }}
          >
            Biomarkers
          </a>
          <a
            href="/investors"
            style={linkStyle}
            onMouseEnter={(e) => {
              (e.target as HTMLAnchorElement).style.opacity = "1";
            }}
            onMouseLeave={(e) => {
              (e.target as HTMLAnchorElement).style.opacity = "0.7";
            }}
          >
            Investors
          </a>
          <a href="#investors" style={ctaStyle}>
            Join Waitlist
          </a>
        </div>

        {/* Mobile/Tablet Fluid Hamburger Button (visible on screens < 1024px) */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="flex lg:hidden flex-col gap-[5px] w-11 h-11 justify-center items-center relative z-[160] mr-[-11px] select-none cursor-pointer focus:outline-none"
          style={{
            background: "none",
            border: "none",
            outline: "none",
          }}
          aria-label="Toggle menu"
        >
          <motion.span
            animate={menuOpen ? { rotate: 45, y: 6.5 } : { rotate: 0, y: 0 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            style={{
              display: "block",
              width: 22,
              height: 1.5,
              backgroundColor: "#0A0A0A",
              transformOrigin: "center",
            }}
          />
          <motion.span
            animate={menuOpen ? { opacity: 0 } : { opacity: 1 }}
            transition={{ duration: 0.2 }}
            style={{
              display: "block",
              width: 22,
              height: 1.5,
              backgroundColor: "#0A0A0A",
            }}
          />
          <motion.span
            animate={menuOpen ? { rotate: -45, y: -6.5 } : { rotate: 0, y: 0 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            style={{
              display: "block",
              width: 22,
              height: 1.5,
              backgroundColor: "#0A0A0A",
              transformOrigin: "center",
            }}
          />
        </button>
      </nav>

      {/* Mobile/Tablet Sliding Drawer & Backdrop - ONLY rendered when open to prevent vertical spacing impact and text leaks */}
      {menuOpen && (
        <div
          className="lg:hidden"
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 150,
          }}
        >
          {/* Backdrop overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2 }}
            onClick={() => setMenuOpen(false)}
            className="absolute inset-0 bg-black/30 backdrop-blur-md"
            style={{
              position: "absolute",
              inset: 0,
              backgroundColor: "rgba(0,0,0,0.3)",
              backdropFilter: "blur(8px)",
              WebkitBackdropFilter: "blur(8px)",
            }}
          />

          {/* Drawer container */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 220 }}
            style={{
              position: "absolute",
              top: 0,
              right: 0,
              height: "100%",
              width: "100%",
              maxWidth: 320,
              backgroundColor: "#FAFAF9",
              color: "#0A0A0A",
              padding: 32,
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              boxShadow: "-10px 0 30px rgba(0,0,0,0.05)",
              borderLeft: "1px solid rgba(0,0,0,0.05)",
              zIndex: 160,
            }}
          >
            <div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  borderBottom: "1px solid rgba(0,0,0,0.06)",
                  paddingBottom: 24,
                  marginBottom: 40,
                }}
              >
                <span
                  style={{
                    fontSize: 13,
                    letterSpacing: "0.25em",
                    textTransform: "uppercase",
                    fontWeight: 600,
                    fontFamily: "'Inter', system-ui, sans-serif",
                    color: "#0A0A0A",
                  }}
                >
                  NeviSense
                </span>
                <button
                  onClick={() => setMenuOpen(false)}
                  style={{
                    width: 44,
                    height: 44,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#888",
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                  }}
                  aria-label="Close menu"
                >
                  <svg
                    style={{ width: 24, height: 24 }}
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={1.5}
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              <nav style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {[
                  { label: "About", href: "/about" },
                  { label: "Platform", href: "/platform" },
                  { label: "Biomarkers", href: "/biomarkers" },
                  { label: "Investors", href: "/investors" },
                ].map((item) => (
                  <a
                    key={item.label}
                    href={item.href}
                    onClick={() => setMenuOpen(false)}
                    style={{
                      padding: "16px 0",
                      fontSize: 14,
                      fontWeight: 400,
                      color: "#444",
                      textDecoration: "none",
                      textTransform: "uppercase",
                      letterSpacing: "0.15em",
                      borderBottom: "1px solid rgba(0,0,0,0.02)",
                      display: "block",
                    }}
                    onMouseEnter={(e) => {
                      (e.target as HTMLAnchorElement).style.color = "#C41E3A";
                    }}
                    onMouseLeave={(e) => {
                      (e.target as HTMLAnchorElement).style.color = "#444";
                    }}
                  >
                    {item.label}
                  </a>
                ))}
              </nav>
            </div>

            <div style={{ paddingTop: 32, borderTop: "1px solid rgba(0,0,0,0.06)" }}>
              <a
                href="#investors"
                onClick={() => setMenuOpen(false)}
                style={{
                  width: "100%",
                  textAlign: "center",
                  display: "block",
                  fontSize: 11,
                  letterSpacing: "0.15em",
                  textTransform: "uppercase",
                  fontWeight: 500,
                  color: "#FFFFFF",
                  padding: "14px 0",
                  backgroundColor: "#C41E3A",
                  borderRadius: 2,
                  textDecoration: "none",
                  fontFamily: "'Inter', system-ui, sans-serif",
                }}
              >
                Join Waitlist
              </a>
            </div>
          </motion.div>
        </div>
      )}
    </>
  );
}
