"use client";
import React, { useState } from "react";
import RevealText, { RevealLine } from "./RevealText";
import ThreeSculpture from "./ThreeSculpture";
import { useScrollReveal } from "./useScrollReveal";
import Modal from "./Modal";

const FONT = "'Inter', system-ui, -apple-system, sans-serif";
const RED = "#C41E3A";

// ==========================================
// VISION SECTION
// ==========================================
export function VisionSection() {
  return (
    <section
      id="vision"
      style={{
        backgroundColor: "#080808",
        padding: "clamp(60px, 10vw, 160px) clamp(16px, 6vw, 120px)",
      }}
    >
      <RevealText delay={0}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            marginBottom: "clamp(40px, 6vw, 80px)",
          }}
        >
          <div style={{ width: 28, height: 1, backgroundColor: RED }} />
          <span
            style={{
              fontSize: 11,
              letterSpacing: "0.25em",
              textTransform: "uppercase",
              color: RED,
              fontWeight: 500,
              fontFamily: FONT,
            }}
          >
            Vision
          </span>
        </div>
      </RevealText>
      
      <div style={{ display: "flex", flexDirection: "column", gap: "clamp(24px, 4vw, 40px)", maxWidth: 840 }}>
        <RevealLine delay={0.1}>
          <p
            style={{
              margin: 0,
              fontFamily: FONT,
              fontWeight: 200,
              fontSize: "clamp(20px, 2.8vw, 36px)",
              letterSpacing: "-0.02em",
              color: "#FFFFFF",
              lineHeight: 1.35,
            }}
          >
            To become the world&apos;s leading intelligent mobility platform for visually impaired individuals, empowering millions through accessible technology, artificial intelligence, and human-centered design.
          </p>
        </RevealLine>
        <RevealLine delay={0.25}>
          <p
            style={{
              margin: 0,
              fontFamily: FONT,
              fontWeight: 200,
              fontSize: "clamp(16px, 1.8vw, 22px)",
              letterSpacing: "-0.01em",
              color: "rgba(255,255,255,0.55)",
              lineHeight: 1.5,
            }}
          >
            We envision a future where assistive technology does more than react—it understands, learns, and adapts to each individual&apos;s unique lifestyle and environment.
          </p>
        </RevealLine>
      </div>
    </section>
  );
}

// ==========================================
// INVESTOR SECTION
// ==========================================
interface IntersectionRowProps {
  label: string;
  index: number;
}

function IntersectionRow({ label, index }: IntersectionRowProps) {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });
  const [hovered, setHovered] = useState(false);
  return (
    <div
      ref={ref}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        borderTop: "1px solid rgba(255,255,255,0.06)",
        padding: "18px 0",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        cursor: "default",
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? "translateX(0)" : "translateX(-24px)",
        transition: `opacity 0.7s ease ${index * 0.08}s, transform 0.7s cubic-bezier(0.76,0,0.24,1) ${index * 0.08}s`,
      }}
    >
      <span
        style={{
          fontSize: 15,
          fontFamily: FONT,
          fontWeight: 300,
          color: hovered ? "#FFFFFF" : "rgba(255,255,255,0.5)",
          transition: "color 0.2s ease",
        }}
      >
        {label}
      </span>
      <span
        style={{
          fontSize: 10,
          color: RED,
          opacity: hovered ? 1 : 0,
          transition: "opacity 0.2s ease",
        }}
      >
        ➔
      </span>
    </div>
  );
}

export function InvestorSection() {
  const [emailValue, setEmailValue] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [hoveredBtn, setHoveredBtn] = useState<number | null>(null);
  const [modal, setModal] = useState<"investor" | "partner" | "contact" | null>(null);

  const intersections = [
    "Accessibility",
    "Artificial Intelligence",
    "Digital Biomarkers",
    "Mobility Analytics",
    "Assistive Technology",
  ];

  const btns = [
    { label: "Request Investor Deck", primary: true },
    { label: "Partner With Us", primary: false },
    { label: "Contact Us", primary: false },
  ];

  return (
    <section
      id="investors"
      style={{
        backgroundColor: "#000000",
        padding: "clamp(60px, 10vw, 160px) clamp(16px, 6vw, 120px)",
      }}
    >
      <div
        className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24"
      >
        {/* Left column */}
        <div>
          <RevealText delay={0}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                marginBottom: "clamp(24px, 4vw, 48px)",
              }}
            >
              <div style={{ width: 28, height: 1, backgroundColor: RED }} />
              <span
                style={{
                  fontSize: 11,
                  letterSpacing: "0.25em",
                  textTransform: "uppercase",
                  color: RED,
                  fontWeight: 500,
                  fontFamily: FONT,
                }}
              >
                Investors
              </span>
            </div>
          </RevealText>

          <RevealLine delay={0.1}>
            <h2
              style={{
                margin: "0 0 24px 0",
                fontFamily: FONT,
                fontWeight: 200,
                fontSize: "clamp(28px, 4.5vw, 60px)",
                letterSpacing: "-0.035em",
                color: "#FFFFFF",
                lineHeight: 1.1,
              }}
            >
              Building The Future Of Mobility Intelligence.
            </h2>
          </RevealLine>

          <RevealText delay={0.2}>
            <p
              style={{
                margin: "0 0 32px 0",
                fontSize: "clamp(13px, 1.1vw, 15px)",
                color: "rgba(255,255,255,0.4)",
                 fontFamily: FONT,
                fontWeight: 300,
                lineHeight: 1.7,
              }}
            >
              NeviSense operates at the intersection of accessibility, artificial
              intelligence, and digital biomarker technology — creating meaningful
              impact while unlocking entirely new possibilities in human mobility
              understanding.
            </p>
          </RevealText>

          <RevealText delay={0.3}>
            <div className="flex flex-col sm:flex-row w-full gap-3 mt-8">
              {btns.map((btn, i) => (
                <button
                  key={i}
                  onClick={() =>
                    setModal(
                      btn.label === "Request Investor Deck"
                        ? "investor"
                        : btn.label === "Partner With Us"
                        ? "partner"
                        : "contact"
                    )
                  }
                  onMouseEnter={() => setHoveredBtn(i)}
                  onMouseLeave={() => setHoveredBtn(null)}
                  className="w-full sm:w-auto text-center cursor-pointer min-h-[46px] flex items-center justify-center uppercase tracking-wider font-semibold"
                  style={{
                    padding: "13px 24px",
                    fontSize: 11,
                    letterSpacing: "0.12em",
                    textTransform: "uppercase",
                    fontWeight: 500,
                    fontFamily: FONT,
                    border: "1px solid",
                    borderColor: btn.primary ? RED : "rgba(255,255,255,0.15)",
                    backgroundColor: btn.primary
                      ? hoveredBtn === i
                        ? "#A01530"
                        : RED
                      : hoveredBtn === i
                      ? "rgba(255,255,255,0.05)"
                      : "transparent",
                    color: btn.primary ? "#FFFFFF" : "rgba(255,255,255,0.6)",
                    transition:
                      "background-color 0.2s ease, border-color 0.2s ease, color 0.2s ease",
                  }}
                >
                  {btn.label}
                </button>
              ))}
            </div>
          </RevealText>
        </div>

        {/* Right - Intersections */}
        <div>
          <RevealText delay={0.2}>
            <p
              style={{
                fontSize: 11,
                letterSpacing: "0.2em",
                color: "rgba(255,255,255,0.25)",
                fontFamily: FONT,
                textTransform: "uppercase",
                marginBottom: 32,
                fontWeight: 500,
              }}
            >
              Operating At The Intersection Of
            </p>
          </RevealText>
          <div style={{ display: "flex", flexDirection: "column" }}>
            {intersections.map((item, i) => (
              <IntersectionRow key={i} label={item} index={i} />
            ))}
            <div style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }} />
          </div>

          {/* Email capture */}
          <RevealText delay={0.6}>
            <div style={{ marginTop: 64 }}>
              <p
                style={{
                  fontSize: 12,
                  color: "rgba(255,255,255,0.35)",
                  fontFamily: FONT,
                  marginBottom: 16,
                  fontWeight: 300,
                  letterSpacing: "0.05em",
                }}
              >
                Stay informed about NeviSense developments
              </p>
              {!submitted ? (
                <div style={{ display: "flex", gap: 0 }}>
                  <input
                    type="email"
                    value={emailValue}
                    onChange={(e) => setEmailValue(e.target.value)}
                    placeholder="your@email.com"
                    style={{
                      flex: 1,
                      padding: "13px 20px",
                      backgroundColor: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRight: "none",
                      color: "#FFFFFF",
                      fontSize: 13,
                      fontFamily: FONT,
                      outline: "none",
                    }}
                  />
                  <button
                    onClick={() => emailValue && setSubmitted(true)}
                    style={{
                      padding: "13px 24px",
                      backgroundColor: RED,
                      color: "#fff",
                      border: `1px solid ${RED}`,
                      cursor: "pointer",
                      fontSize: 11,
                      letterSpacing: "0.15em",
                      textTransform: "uppercase",
                      fontFamily: FONT,
                      fontWeight: 500,
                    }}
                  >
                    Join
                  </button>
                </div>
              ) : (
                <p
                  style={{
                    fontSize: 13,
                    color: RED,
                    fontFamily: FONT,
                    fontWeight: 300,
                  }}
                >
                  ✓ You&apos;re on the list. We&apos;ll be in touch.
                </p>
              )}
            </div>
          </RevealText>

          {/* Modals */}
          <Modal
            open={modal === "investor"}
            onClose={() => setModal(null)}
            title="Request Investor Deck"
            description="Interested in the investment opportunity? Fill in your details and we'll send the deck to your inbox."
            fields={[
              { name: "name", placeholder: "Full Name", type: "text", required: true },
              { name: "email", placeholder: "Email Address", type: "email", required: true },
              { name: "company", placeholder: "Company / Fund (optional)", type: "text" },
            ]}
            submitLabel="Request Deck"
          />
          <Modal
            open={modal === "partner"}
            onClose={() => setModal(null)}
            title="Partner With Us"
            description="Interested in partnering with NeviSense? Let us know about your organization and how we can collaborate."
            fields={[
              { name: "name", placeholder: "Full Name", type: "text", required: true },
              { name: "email", placeholder: "Email Address", type: "email", required: true },
              { name: "org", placeholder: "Organization", type: "text", required: true },
              { name: "message", placeholder: "How would you like to partner? (optional)", type: "text" },
            ]}
            submitLabel="Submit Interest"
          />
          <Modal
            open={modal === "contact"}
            onClose={() => setModal(null)}
            title="Contact Us"
            description="Have a question or want to learn more? Send us a message and we'll get back to you."
            fields={[
              { name: "name", placeholder: "Full Name", type: "text", required: true },
              { name: "email", placeholder: "Email Address", type: "email", required: true },
              { name: "message", placeholder: "Your Message", type: "text", required: true },
            ]}
            submitLabel="Send Message"
          />
        </div>
      </div>
    </section>
  );
}

// ==========================================
// FINAL SECTION
// ==========================================
export function FinalSection() {
  const [modal, setModal] = useState<"waitlist" | "demo" | "partner" | "investor" | null>(null);

  interface FooterLinkItem {
    label: string;
    href?: string;
    onClick?: () => void;
    badge?: string;
  }

  interface FooterColumn {
    title: string;
    links: FooterLinkItem[];
  }

  const footerLinks: FooterColumn[] = [
    {
      title: "Product",
      links: [
        { label: "Overview", href: "#about" },
        { label: "Biomarkers", href: "#biomarkers" },
        { label: "Core Features", href: "#features" },
        { label: "Clinical Utility", href: "#about" },
        { label: "System Status", href: "#", badge: "Online" }
      ]
    },
    {
      title: "Solutions",
      links: [
        { label: "Join Waitlist", onClick: () => setModal("waitlist") },
        { label: "Request Product Demo", onClick: () => setModal("demo") },
        { label: "Investor Relations", href: "#investors" },
        { label: "Partner Program", onClick: () => setModal("partner") }
      ]
    },
    {
      title: "Resources",
      links: [
        { label: "Clinical Studies", href: "#" },
        { label: "Digital Biomarkers Guide", href: "#" },
        { label: "Research Publications", href: "#" },
        { label: "Developer Docs", href: "#" }
      ]
    },
    {
      title: "Legal",
      links: [
        { label: "Terms of Service", href: "#" },
        { label: "Privacy Policy", href: "#" },
        { label: "GDPR & HIPAA Compliance", href: "#" },
        { label: "Data Security Protocols", href: "#" }
      ]
    }
  ];

  return (
    <section
      id="footer"
      className="bg-zinc-50 border-t border-zinc-200/80 text-zinc-900"
      style={{
        fontFamily: FONT,
        padding: "100px clamp(24px, 8vw, 160px) 48px",
        position: "relative"
      }}
    >
      <div className="max-w-[1440px] mx-auto">
        
        {/* Middle Section - Links Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-10 md:gap-8 mb-20">
          {footerLinks.map((column, cIdx) => (
            <div key={cIdx} className="flex flex-col gap-5">
              <h4 className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest">
                {column.title}
              </h4>
              <ul className="flex flex-col gap-3">
                {column.links.map((link, lIdx) => (
                  <li key={lIdx}>
                    {link.onClick ? (
                      <button
                        onClick={link.onClick}
                        className="text-[13px] text-zinc-600 hover:text-red-700 transition-colors duration-200 cursor-pointer font-light hover:underline text-left"
                      >
                        {link.label}
                      </button>
                    ) : (
                      <a
                        href={link.href}
                        className="text-[13px] text-zinc-600 hover:text-red-700 transition-colors duration-200 cursor-pointer font-light hover:underline inline-flex items-center gap-2"
                      >
                        {link.label}
                        {link.badge && (
                          <span className="text-[9px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/50 px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                            {link.badge}
                          </span>
                        )}
                      </a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Section - Copyright & Branded Info */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 pt-8 border-t border-zinc-200/60">
          <div className="flex items-center gap-6">
            <p className="text-xs text-zinc-500 font-light tracking-wide">
              © {new Date().getFullYear()} NeviSense. All rights reserved.
            </p>
            {/* Status Indicator */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-emerald-50/50 border border-emerald-100 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-medium text-emerald-700 tracking-wide">
                SYSTEMS LIVE
              </span>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <span className="text-xs text-zinc-400 font-light tracking-wider uppercase">
              Mobility Intelligence
            </span>
          </div>
        </div>

      </div>

      {/* Modals */}
      <Modal
        open={modal === "waitlist"}
        onClose={() => setModal(null)}
        title="Join the Waitlist"
        description="Be among the first to experience NeviSense. Sign up to get early access and updates."
        fields={[
          { name: "name", placeholder: "Full Name", type: "text", required: true },
          { name: "email", placeholder: "Email Address", type: "email", required: true },
        ]}
        submitLabel="Join Waitlist"
      />
      <Modal
        open={modal === "demo"}
        onClose={() => setModal(null)}
        title="Request a Demo"
        description="See NeviSense in action. Tell us about yourself and we'll arrange a personalized demo."
        fields={[
          { name: "name", placeholder: "Full Name", type: "text", required: true },
          { name: "email", placeholder: "Email Address", type: "email", required: true },
          { name: "org", placeholder: "Organization (optional)", type: "text" },
        ]}
        submitLabel="Request Demo"
      />
      <Modal
        open={modal === "partner"}
        onClose={() => setModal(null)}
        title="Partner With Us"
        description="Interested in partnering with NeviSense? Let us know about your organization and how we can collaborate."
        fields={[
          { name: "name", placeholder: "Full Name", type: "text", required: true },
          { name: "email", placeholder: "Email Address", type: "email", required: true },
          { name: "org", placeholder: "Organization", type: "text", required: true },
          { name: "message", placeholder: "How would you like to partner? (optional)", type: "text" },
        ]}
        submitLabel="Submit Interest"
      />
      <Modal
        open={modal === "investor"}
        onClose={() => setModal(null)}
        title="Request Investor Deck"
        description="Interested in the investment opportunity? Fill in your details and we'll send the deck to your inbox."
        fields={[
          { name: "name", placeholder: "Full Name", type: "text", required: true },
          { name: "email", placeholder: "Email Address", type: "email", required: true },
          { name: "company", placeholder: "Company / Fund (optional)", type: "text" },
        ]}
        submitLabel="Request Deck"
      />
    </section>
  );
}
