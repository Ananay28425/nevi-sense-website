'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Compass, Eye, ShieldCheck, Heart, Signal, Cpu, Share2, Layers } from 'lucide-react';

export default function BentoGrid() {
  const [activeTab, setActiveTab] = useState<'sonar' | 'camera' | 'nodes' | 'haptic'>('sonar');
  const [currentTime, setCurrentTime] = useState<number>(1710000000000);
  const idCounterRef = useRef<number>(0);

  // Initialize and update local timestamp for pure render outputs
  useEffect(() => {
    let active = true;
    const timer = setTimeout(() => {
      if (active) setCurrentTime(Date.now());
    }, 0);
    const interval = setInterval(() => {
      if (active) setCurrentTime(Date.now());
    }, 30);
    return () => {
      active = false;
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, []);
  
  // States for Sonar Simulation
  const [sonarRate, setSonarRate] = useState(1);
  const [sonarBeacons, setSonarBeacons] = useState<{ id: string; r: number; opacity: number }[]>([]);
  const sonarIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // States for AI Camera Viewport
  const [gridLines, setGridLines] = useState<number>(0);
  const [cameraCoordinates, setCameraCoordinates] = useState({ x: 342, y: 195, dist: 1.8 });
  const [detectedClass, setDetectedClass] = useState<'Steps' | 'Tactile Block' | 'Path Clear' | 'Obstacle' | 'Doorway'>('Path Clear');

  // States for Node Graph
  const [activeNode, setActiveNode] = useState(0);

  // States for Haptics Canvas
  const [hapticRipple, setHapticRipple] = useState<{ x: number, y: number, id: string, time: number }[]>([]);

  // 1. Sonar Simulation Effects
  useEffect(() => {
    const triggerWave = () => {
      idCounterRef.current += 1;
      const uniqueId = `beacon-${Date.now()}-${idCounterRef.current}`;
      setSonarBeacons((prev) => [...prev, { id: uniqueId, r: 5, opacity: 1 }]);
    };
    
    // Set periodic pulse
    const interval = setInterval(triggerWave, 2000 / sonarRate);
    return () => clearInterval(interval);
  }, [sonarRate]);

  useEffect(() => {
    const animId = setInterval(() => {
      setSonarBeacons((prev) =>
        prev
          .map((wave) => ({
            ...wave,
            r: wave.r + 2,
            opacity: Math.max(0, 1 - wave.r / 140),
          }))
          .filter((w) => w.opacity > 0)
      );
    }, 30);
    return () => clearInterval(animId);
  }, []);

  // 2. Camera Viewport Coordinates simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setCameraCoordinates(() => {
        const xOffset = Math.sin(Date.now() * 0.003) * 60;
        const yOffset = Math.cos(Date.now() * 0.002) * 40;
        const distOffset = Math.sin(Date.now() * 0.001) * 0.6;
        
        return {
          x: Math.round(320 + xOffset),
          y: Math.round(200 + yOffset),
          dist: parseFloat((2.1 + distOffset).toFixed(1)),
        };
      });

      // Cycling detected labels
      const classes: ('Steps' | 'Tactile Block' | 'Path Clear' | 'Obstacle' | 'Doorway')[] = [
        'Path Clear', 'Tactile Block', 'Path Clear', 'Steps', 'Doorway', 'Obstacle'
      ];
      const index = Math.floor((Date.now() / 3500) % classes.length);
      setDetectedClass(classes[index]);
    }, 150);

    return () => clearInterval(timer);
  }, []);

  // 3. Node Graph Cycle
  useEffect(() => {
    const sequence = setInterval(() => {
      setActiveNode((prev) => (prev + 1) % 5);
    }, 1500);
    return () => clearInterval(sequence);
  }, []);

  const triggerHaptic = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    idCounterRef.current += 1;
    const uniqueId = `haptic-${Date.now()}-${idCounterRef.current}`;
    const timestamp = Date.now();
    
    setHapticRipple((prev) => [...prev, { x, y, id: uniqueId, time: timestamp }]);
    
    if (hapticRipple.length > 5) {
      setHapticRipple((prev) => prev.slice(1));
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setHapticRipple((prev) =>
        prev.map((r) => ({ ...r })).filter((r) => Date.now() - r.time < 1200)
      );
    }, 50);
    return () => clearInterval(interval);
  }, [hapticRipple]);

  const nodes = [
    { label: 'Spatial Sensor Scan', desc: '140° Lidar telemetry' },
    { label: 'Cloud Tensor Vectorizer', desc: 'Deep-learning semantic model' },
    { label: 'Haptic Actuator Mapping', desc: 'Stereo frequency micro-vibrations' },
    { label: 'Natural Voice Guidance', desc: 'Conversational sound cues' },
    { label: 'Autonomy Lock System', desc: 'Fail-safe safety mapping' },
  ];

  return (
    <div className="w-full max-w-7xl mx-auto px-6 py-20 bg-[#FAFAF9]" id="platform">
      <div className="mb-14 max-w-2xl">
        <div className="mb-4 inline-flex items-center gap-2 text-[#C41E3A] font-bold tracking-[0.2em] text-[10px] uppercase">
          <span className="w-8 h-[2px] bg-[#C41E3A]"></span>
          SENSORY COGNITION SYSTEM
        </div>
        <h2 className="text-3xl md:text-5xl font-display font-black tracking-tight text-[#0A0A0A] mb-4 uppercase">
          The Sensory Translation Platform
        </h2>
        <p className="text-[#78716C] text-sm md:text-base font-semibold leading-relaxed">
          NeviSense converts real-time spatial physics into high-fidelity haptic waveforms and acoustic maps, bypassing retinal channels entirely.
        </p>
      </div>

      {/* Grid Canvas */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-6">
        
        {/* Card 1: Sonar Mapping (Col span 3) */}
        <div className="md:col-span-3 border-2 border-[#0A0A0A]/10 bg-white rounded-none p-6 md:p-8 flex flex-col justify-between overflow-hidden relative group/sonar min-h-[400px]">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <span className="p-2.5 rounded-none bg-[#FAFAF9] border border-black/10 text-[#C41E3A]">
                <Signal className="w-5 h-5 animate-pulse" />
              </span>
              <div>
                <span className="font-mono text-[10px] text-[#A8A29E] block">SENSING ARRAY</span>
                <h3 className="font-display font-bold text-lg text-[#0A0A0A] uppercase">Real-Time Spatial Sonar</h3>
              </div>
            </div>
            <p className="text-xs font-mono text-[#78716C] leading-relaxed max-w-md">
              High-frequency sensory echo arrays. Emits micro-acoustic tracking soundscapes that map nearby room topography continuously.
            </p>
          </div>

          {/* Interactive Sonar Display Frame */}
          <div className="my-6 relative h-40 bg-[#FAFAF9] border-2 border-black/5 rounded-none flex items-center justify-center overflow-hidden">
            {/* Center dot */}
            <div className="w-3 h-3 bg-[#C41E3A] rounded-full z-10 relative shadow-[0_0_12px_rgba(196,30,58,0.4)]"></div>
            
            {/* Compass sweep line */}
            <div 
              className="absolute w-full h-[1px] bg-gradient-to-r from-transparent via-[#C41E3A]/40 to-transparent origin-center"
              style={{
                transform: `rotate(${(currentTime / 15) % 360}deg)`,
              }}
            ></div>

            {/* Rippling sonar rings */}
            {sonarBeacons.map((beacon) => (
              <div
                key={beacon.id}
                className="absolute border border-[#C41E3A]/30 rounded-full"
                style={{
                  width: `${beacon.r * 2}px`,
                  height: `${beacon.r * 2}px`,
                  opacity: beacon.opacity,
                  transition: 'width 0.03s linear, height 0.03s linear, opacity 0.03s linear',
                }}
              />
            ))}

            {/* Simulated obstacle targets */}
            <div className="absolute top-1/4 left-1/3 w-1.5 h-1.5 bg-[#78716C] rounded-full opacity-60 animate-ping"></div>
            <div className="absolute bottom-1/3 right-1/4 w-2 h-2 bg-[#C41E3A] rounded-full opacity-80 animate-pulse"></div>

            {/* Readout stats overlay */}
            <div className="absolute bottom-2 left-3 font-mono text-[9px] text-[#78716C] space-y-0.5">
              <div>RANGE: 4.8 METERS</div>
              <div>RATE: {sonarRate}x INTERVAL</div>
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-[#E5E5E0] pt-4 mt-auto">
            <span className="text-[11px] font-mono text-[#78716C]">Adjust Pulse Density:</span>
            <div className="flex gap-1 bg-[#FAFAF9] p-0.5 border border-[#E5E5E0] rounded-none">
              {[1, 2, 3].map((rate) => (
                <button
                  key={rate}
                  onClick={() => setSonarRate(rate)}
                  className={`px-3 py-1 text-[10px] font-mono rounded-none transition-colors ${
                    sonarRate === rate
                      ? 'bg-[#C41E3A] text-white'
                      : 'text-[#78716C] hover:text-[#0A0A0A]'
                  }`}
                >
                  {rate}Hz
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Card 2: AI Vision & Target Acquisition (Col span 3) */}
        <div className="md:col-span-3 border-2 border-[#0A0A0A]/10 bg-white rounded-none p-6 md:p-8 flex flex-col justify-between overflow-hidden relative group/vision min-h-[400px]">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <span className="p-2.5 rounded-none bg-[#FAFAF9] border border-black/10 text-[#C41E3A]">
                <Eye className="w-5 h-5" />
              </span>
              <div>
                <span className="font-mono text-[10px] text-[#A8A29E] block">COGNITIVE PATHING</span>
                <h3 className="font-display font-bold text-lg text-[#0A0A0A] uppercase">Intelligent AI Vision</h3>
              </div>
            </div>
            <p className="text-xs font-mono text-[#78716C] leading-relaxed max-w-md">
              Real-time deep neural networks extract surrounding spatial landmarks to isolate walkways, steps, walls, and potential obstructions.
            </p>
          </div>

          {/* AI Vision Mock Cam Feed */}
          <div className="my-6 relative h-40 bg-[#0A0A0A] border-2 border-white/5 rounded-none overflow-hidden font-mono flex items-center justify-center">
            {/* Background scanner sweep grids */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(196,30,58,0.15)_0%,transparent_75%)]" />
            <div className="absolute inset-0 opacity-10 bg-[linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:10px_10px]" />
            
            {/* Bounding diagnostic boxes targeting elements inside vector frame */}
            <div 
              className="absolute border border-dashed border-[#C41E3A] rounded p-2 transition-all duration-300 flex flex-col justify-between"
              style={{
                left: `${cameraCoordinates.x - 70}px`,
                top: `${cameraCoordinates.y - 70}px`,
                width: '120px',
                height: '80px',
              }}
            >
              <div className="text-[8px] bg-[#C41E3A] text-white px-1 leading-none py-0.5 rounded-none self-start">
                {detectedClass}
              </div>
              <div className="text-[8px] text-[#C41E3A] text-right mt-auto font-medium">
                {cameraCoordinates.dist}m
              </div>
            </div>

            {/* Static diagnostic target lines overlay */}
            <div className="absolute left-[10%] top-4 w-4 h-4 border-l border-t border-neutral-600 opacity-60"></div>
            <div className="absolute right-[10%] top-4 w-4 h-4 border-r border-t border-neutral-600 opacity-60"></div>
            <div className="absolute left-[10%] bottom-4 w-4 h-4 border-l border-b border-neutral-600 opacity-60"></div>
            <div className="absolute right-[10%] bottom-4 w-4 h-4 border-r border-b border-neutral-600 opacity-60"></div>

            {/* Real-time coordinates overlays */}
            <div className="absolute top-2 right-3 text-[9px] text-neutral-400 font-mono tracking-wider">
              LATENCY: 14ms // CONF: 99.4%
            </div>
            
            <div className="absolute left-3 bottom-2 text-[9px] text-[#C41E3A] font-mono select-none flex items-center gap-1.5 animate-pulse">
              <span className="w-1.5 h-1.5 bg-[#C41E3A] rounded-full"></span>
              <span>LIVE CORE ACQUISITION</span>
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-[#E5E5E0] pt-4 mt-auto">
            <span className="text-[11px] font-mono text-[#78716C]">SENSORY CLASS STATUS:</span>
            <span className="text-xs font-mono font-medium text-[#C41E3A] px-2 py-0.5 bg-[#C41E3A]/10 rounded-none border border-[#C41E3A]/20">
              {detectedClass.toUpperCase()}
            </span>
          </div>
        </div>

        {/* Card 3: Contextual Semantic Node Graph (Col span 3) */}
        <div className="md:col-span-3 border-2 border-[#0A0A0A]/10 bg-white rounded-none p-6 md:p-8 flex flex-col justify-between overflow-hidden relative group/nodes min-h-[440px]">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <span className="p-2.5 rounded-none bg-[#FAFAF9] border border-black/10 text-[#C41E3A]">
                <Cpu className="w-5 h-5 animate-pulse" />
              </span>
              <div>
                <span className="font-mono text-[10px] text-[#A8A29E] block">COGNITIVE ENGINE</span>
                <h3 className="font-display font-bold text-lg text-[#0A0A0A] uppercase">Spatial Semantic Pathways</h3>
              </div>
            </div>
            <p className="text-xs font-mono text-[#78716C] leading-relaxed max-w-md">
              A high-precision modular pathway transforming physics into conceptual milestones. It chains telemetry blocks to generate clear mental mappings.
            </p>
          </div>

          {/* Node graph flow */}
          <div className="my-6 py-4 flex flex-col gap-3.5 pl-4 relative before:absolute before:left-7 before:top-4 before:bottom-4 before:w-[1px] before:bg-black/10">
            {nodes.map((node, index) => {
              const isActive = index === activeNode;
              return (
                <div 
                  key={index} 
                  className={`flex items-start gap-4 relative transition-all duration-300 ${
                    isActive ? 'scale-101 translate-x-1' : 'opacity-40 hover:opacity-60'
                  }`}
                  style={{ transitionDelay: `${index * 50}ms` }}
                >
                  <div className={`w-6 h-6 rounded-none border flex items-center justify-center font-mono text-[10px] shrink-0 font-medium z-10 transition-colors duration-300 ${
                    isActive 
                      ? 'bg-[#C41E3A] text-white border-[#C41E3A] shadow-md shadow-[#C41E3A]/20' 
                      : 'bg-white text-[#78716C] border-black/10'
                  }`}>
                    {index + 1}
                  </div>
                  <div>
                    <h4 className={`text-xs font-bold uppercase transition-colors ${
                      isActive ? 'text-[#C41E3A]' : 'text-[#0A0A0A]'
                    }`}>
                      {node.label}
                    </h4>
                    <p className="text-[10px] font-sans text-[#78716C]">{node.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="border-t border-[#E5E5E0] pt-4 mt-auto">
            <div className="flex justify-between items-center text-[10px] font-mono text-[#78716C]">
              <span>NODE STATE SHIFTER</span>
              <span className="animate-pulse text-[#C41E3A]">CYCLES ACTIVE</span>
            </div>
          </div>
        </div>

        {/* Card 4: Interactive Haptic Feedback Waves (Col span 3) */}
        <div className="md:col-span-3 border-2 border-[#0A0A0A]/10 bg-white rounded-none p-6 md:p-8 flex flex-col justify-between overflow-hidden relative group/haptic min-h-[440px]">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <span className="p-2.5 rounded-none bg-[#FAFAF9] border border-black/10 text-[#C41E3A]">
                <Layers className="w-5 h-5" />
              </span>
              <div>
                <span className="font-mono text-[10px] text-[#A8A29E] block">TOUCH INTERACTION</span>
                <h3 className="font-display font-bold text-lg text-[#0A0A0A] uppercase">Haptic Translation Waves</h3>
              </div>
            </div>
            <p className="text-xs font-mono text-[#78716C] leading-relaxed max-w-md">
              Tap anywhere inside the black grid region to simulate standard haptic audio translation waves. Feels spatial stereo pulses in dynamic sync.
            </p>
          </div>

          <div 
            onClick={triggerHaptic}
            className="my-6 relative h-48 bg-[#0A0A0A] border-2 border-white/5 rounded-none overflow-hidden cursor-crosshair flex items-center justify-center font-mono active:bg-neutral-950 transition-colors duration-150"
          >
            {/* Guidance Grid Background */}
            <div className="absolute inset-0 opacity-15 bg-[linear-gradient(rgba(255,255,255,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:16px_16px]" />
            
            {hapticRipple.map((r) => {
              const elapsed = currentTime - r.time;
              const scale = Math.min(6, elapsed / 180);
              const opacity = Math.max(0, 1 - elapsed / 1000);
              
              return (
                <div key={r.id}>
                  {/* Expanding haptic wave ring */}
                  <div
                    className="absolute border border-brand/50 rounded-full pointer-events-none"
                    style={{
                      left: `${r.x}px`,
                      top: `${r.y}px`,
                      width: `${scale * 50}px`,
                      height: `${scale * 50}px`,
                      transform: 'translate(-50%, -50%)',
                      opacity: opacity,
                      boxShadow: '0 0 16px rgba(196,30,58,0.1)',
                    }}
                  />
                  {/* Core flare spark */}
                  <div
                    className="absolute w-2 h-2 bg-white rounded-full pointer-events-none"
                    style={{
                      left: `${r.x}px`,
                      top: `${r.y}px`,
                      transform: 'translate(-50%, -50%)',
                      opacity: opacity,
                    }}
                  />
                </div>
              );
            })}

            {hapticRipple.length === 0 && (
              <div className="text-[10px] text-neutral-500 font-mono tracking-widest text-center uppercase animate-pulse select-none px-4">
                [ Click or Tap Inside to Emit Waves ]
              </div>
            )}

            {/* Micro readouts specs */}
            <div className="absolute top-2 left-3 text-[8px] text-[#A8A29E] space-y-0.5 pointer-events-none">
              <div>VIBRATORY STATE: EMITTER READY</div>
              <div>FREQUENCY: 184 Hz STEREO</div>
            </div>
            
            <div className="absolute bottom-2 right-3 text-[10px] text-[#C41E3A] font-bold animate-pulse pointer-events-none">
              HAP-SYNC v1.4
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-[#E5E5E0] pt-4 mt-auto">
            <span className="text-[11px] font-mono text-[#78716C]">ACTIVES IN POOL:</span>
            <span className="text-xs font-mono font-bold text-neutral-800">
              {hapticRipple.length === 0 ? 'IDLE' : `${hapticRipple.length} ACTIVE IMPULSES`}
            </span>
          </div>
        </div>

      </div>
    </div>
  );
}
