'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, Sparkles, Key, CheckCircle, Download, FileText } from 'lucide-react';

interface WaitlistModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (name: string) => void;
}

export function WaitlistModal({ isOpen, onClose, onSuccess }: WaitlistModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [interest, setInterest] = useState('user');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;

    setIsSubmitting(true);
    
    // Simulate API registration delay
    setTimeout(() => {
      // Save to local storage waitlist
      const currentWaitlist = JSON.parse(localStorage.getItem('nevi_waitlist') || '[]');
      currentWaitlist.push({ name, email, interest, message, date: new Date().toISOString() });
      localStorage.setItem('nevi_waitlist', JSON.stringify(currentWaitlist));

      setIsSubmitting(false);
      onSuccess(name);
      onClose();

      // Clear form
      setName('');
      setEmail('');
      setMessage('');
    }, 1200);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop Blur */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#0A0A0A]/40 backdrop-blur-md"
          />

          {/* Dialog Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-lg bg-white border border-[#E5E5E0] rounded-3xl p-6 md:p-8 shadow-2xl z-10 overflow-hidden"
          >
            {/* Top red header stroke */}
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#C41E3A]"></div>

            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full text-[#78716C] hover:bg-[#FAFAF9] hover:text-[#0A0A0A] transition-colors focus:outline-none"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-6">
              <span className="text-[10px] font-mono tracking-widest text-[#C41E3A] uppercase font-bold block mb-1">
                MEMBERSHIP ENTRY
              </span>
              <h3 className="text-2xl font-display font-medium text-[#0A0A0A]">
                Experience NeviSense
              </h3>
              <p className="text-xs text-[#78716C] font-sans mt-1">
                Be among the first to access the next leap in sensory translation engineering.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-mono font-medium text-[#78716C] uppercase mb-1.5">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Sarah Jenkins"
                  className="w-full text-sm py-2.5 px-4 bg-[#FAFAF9] border border-[#E5E5E0] rounded-xl text-[#0A0A0A] placeholder-neutral-400 focus:outline-none focus:border-[#C41E3A] transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-mono font-medium text-[#78716C] uppercase mb-1.5">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g., sarah@example.com"
                  className="w-full text-sm py-2.5 px-4 bg-[#FAFAF9] border border-[#E5E5E0] rounded-xl text-[#0A0A0A] placeholder-neutral-400 focus:outline-none focus:border-[#C41E3A] transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-mono font-medium text-[#78716C] uppercase mb-1.5">
                  Primary Perspective
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: 'user', label: 'End User' },
                    { value: 'clinician', label: 'Clinician' },
                    { value: 'dev', label: 'Developer' },
                  ].map((role) => (
                    <button
                      key={role.value}
                      type="button"
                      onClick={() => setInterest(role.value)}
                      className={`py-2 px-3 text-xs font-mono rounded-lg border text-center transition-all ${
                        interest === role.value
                          ? 'bg-[#C41E3A] border-[#C41E3A] text-white font-medium'
                          : 'bg-[#FAFAF9] border-[#E5E5E0] text-[#78716C] hover:border-[#A8A29E]'
                      }`}
                    >
                      {role.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono font-medium text-[#78716C] uppercase mb-1.5">
                  Why are you interested in NeviSense? (Optional)
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="How can NeviSense empower your specific journey?"
                  rows={3}
                  className="w-full text-sm py-2.5 px-4 bg-[#FAFAF9] border border-[#E5E5E0] rounded-xl text-[#0A0A0A] placeholder-neutral-400 focus:outline-none focus:border-[#C41E3A] transition-colors resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full mt-2 bg-[#C41E3A] text-white py-3 rounded-xl text-xs font-mono tracking-widest font-bold hover:bg-[#A3182E] transition-colors flex items-center justify-center gap-2 shadow-lg shadow-[#C41E3A]/20 disabled:bg-[#78716C] disabled:shadow-none"
              >
                {isSubmitting ? (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>SECURE ACCESS RESERVATION</span>
                  </>
                )}
              </button>
            </form>

            <div className="mt-5 pt-4 border-t border-[#E5E5E0] flex justify-between items-center text-[9px] font-mono text-[#78716C]">
              <span>100% PERSONAL PRIVACY SECURED</span>
              <span>NEVI GLOBAL PORTAL v1.2</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

interface InvestorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (name: string, fund: string) => void;
}

export function InvestorModal({ isOpen, onClose, onSuccess }: InvestorModalProps) {
  const [name, setName] = useState('');
  const [fund, setFund] = useState('');
  const [bracket, setBracket] = useState('$100k - $500k');
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !fund || !email) return;

    setIsSubmitting(true);

    // Simulate API registration delay
    setTimeout(() => {
      // Save to local storage investors registry
      const currentInvestors = JSON.parse(localStorage.getItem('nevi_investors') || '[]');
      currentInvestors.push({ name, fund, bracket, email, date: new Date().toISOString() });
      localStorage.setItem('nevi_investors', JSON.stringify(currentInvestors));

      setIsSubmitting(false);
      onSuccess(name, fund);
      onClose();

      // Clear inputs
      setName('');
      setFund('');
      setEmail('');
    }, 1300);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#0A0A0A]/40 backdrop-blur-md"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-lg bg-white border border-[#E5E5E0] rounded-3xl p-6 md:p-8 shadow-2xl z-10 overflow-hidden"
          >
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#C41E3A]"></div>

            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full text-[#78716C] hover:bg-[#FAFAF9] hover:text-[#0A0A0A] transition-colors focus:outline-none"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-6">
              <span className="text-[10px] font-mono tracking-widest text-[#C41E3A] uppercase font-bold block mb-1">
                PARTNERSHIP REGISTER
              </span>
              <h3 className="text-2xl font-display font-medium text-[#0A0A0A]">
                Request Investor Deck
              </h3>
              <p className="text-xs text-[#78716C] font-sans mt-1">
                Access audit details, proprietary clinical diagnostic statistics, and seed funding pipelines.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono font-medium text-[#78716C] uppercase mb-1.5">
                    Contact Name
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g., Frank Chen"
                    className="w-full text-sm py-2.5 px-4 bg-[#FAFAF9] border border-[#E5E5E0] rounded-xl text-[#0A0A0A] placeholder-neutral-400 focus:outline-none focus:border-[#C41E3A] transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-medium text-[#78716C] uppercase mb-1.5">
                    Institution / Fund
                  </label>
                  <input
                    type="text"
                    required
                    value={fund}
                    onChange={(e) => setFund(e.target.value)}
                    placeholder="e.g., Summit Capital"
                    className="w-full text-sm py-2.5 px-4 bg-[#FAFAF9] border border-[#E5E5E0] rounded-xl text-[#0A0A0A] placeholder-neutral-400 focus:outline-none focus:border-[#C41E3A] transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono font-medium text-[#78716C] uppercase mb-1.5">
                  Business Email
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g., f.chen@summitcap.com"
                  className="w-full text-sm py-2.5 px-4 bg-[#FAFAF9] border border-[#E5E5E0] rounded-xl text-[#0A0A0A] placeholder-neutral-400 focus:outline-none focus:border-[#C41E3A] transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-mono font-medium text-[#78716C] uppercase mb-1.5">
                  Target Allocation Range
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {['$100k - $500k', '$500k - $1M+', 'Institutional', 'Strategic Partner'].map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setBracket(opt)}
                      className={`py-2 px-3 text-[11px] font-mono rounded-lg border text-center transition-all ${
                        bracket === opt
                          ? 'bg-[#C41E3A] border-[#C41E3A] text-white font-medium'
                          : 'bg-[#FAFAF9] border-[#E5E5E0] text-[#78716C] hover:border-[#A8A29E]'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full mt-2 bg-[#C41E3A] text-white py-3 rounded-xl text-xs font-mono tracking-widest font-bold hover:bg-[#A3182E] transition-colors flex items-center justify-center gap-2 shadow-lg shadow-[#C41E3A]/20 disabled:bg-[#78716C] disabled:shadow-none"
              >
                {isSubmitting ? (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                ) : (
                  <>
                    <FileText className="w-3.5 h-3.5" />
                    <span>ACQUIRE DECK ACCESS CODE</span>
                  </>
                )}
              </button>
            </form>

            <div className="mt-5 pt-4 border-t border-[#E5E5E0] flex justify-between items-center text-[9px] font-mono text-[#78716C]">
              <span>SEC/FINRA SAFEGUARDS APPLY</span>
              <span>NEVI VENTURES PARTNER SYNC</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
