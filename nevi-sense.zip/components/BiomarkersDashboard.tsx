'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BarChart3, TrendingUp, AlertCircle, RefreshCw, Activity, Layers, ActivitySquare, Brain } from 'lucide-react';

interface MetricData {
  id: string;
  name: string;
  value: string;
  unit: string;
  trend: string;
  status: 'optimal' | 'warning' | 'normal';
  description: string;
  svgPath: string;
  points: number[];
  labels: string[];
}

export default function BiomarkersDashboard() {
  const [selectedMetricId, setSelectedMetricId] = useState<string>('latency');
  const [isSimulating, setIsSimulating] = useState(true);
  const [jitter, setJitter] = useState(0);

  // Dynamic simulation loop to make charts feel completely alive
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      setJitter((prev) => (prev + 1) % 100);
    }, 2500);

    return () => clearInterval(interval);
  }, [isSimulating]);

  const metrics: MetricData[] = [
    {
      id: 'latency',
      name: 'Sensory Translation Latency',
      value: (14 + Math.sin(jitter * 0.4) * 0.8).toFixed(1),
      unit: 'ms',
      trend: '-18.4% improvement in spatial feedback loop speed',
      status: 'optimal',
      description: 'The response time of converting physical camera feed into tactile audio signals. Sub-20ms translations allow real-time walking speeds without nausea or cognitive displacement.',
      svgPath: 'M0,80 Q20,40 40,90 T80,30 T120,60 T160,20 T200,70 T240,40 T280,85 T320,15 T360,65 T400,30',
      points: [16.2, 15.8, 15.4, 14.9, 14.5, 14.2, 14.0, 13.9],
      labels: ['01:00', '02:00', '03:00', '04:00', '05:00', '06:00', '07:00', '08:00']
    },
    {
      id: 'fatigue',
      name: 'Cognitive Computation Load',
      value: (32 + Math.cos(jitter * 0.3) * 2.4).toFixed(0),
      unit: '%',
      trend: '45% reduction in spatial tracking stress levels',
      status: 'normal',
      description: 'Measures brain computational energy used for environmental awareness. Converting complex scenery into organized directional sound cues drastically alleviates constant physical strain.',
      svgPath: 'M0,100 C50,110 100,50 150,60 C200,70 250,20 300,35 C350,50 400,25 450,15',
      points: [78, 65, 54, 48, 41, 38, 35, 32],
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6', 'Week 7', 'Week 8']
    },
    {
      id: 'accuracy',
      name: 'Spatial Navigation Accuracy',
      value: (94.2 + Math.sin(jitter * 0.2) * 0.6).toFixed(1),
      unit: '%',
      trend: '+124% higher path accuracy versus acoustic canes',
      status: 'optimal',
      description: 'Percentage of successfully completed independent courses containing various complex obstacles (like step steps, narrow barriers, street corners, and high signboards) with zero physical impacts.',
      svgPath: 'M0,90 Q40,70 80,60 T160,40 T240,25 T320,10 T400,6',
      points: [42.1, 51.5, 62.8, 74.2, 85.0, 91.3, 93.5, 94.8],
      labels: ['Day 1', 'Day 5', 'Day 10', 'Day 15', 'Day 20', 'Day 25', 'Day 30', 'Day 35']
    }
  ];

  const activeMetric = metrics.find(m => m.id === selectedMetricId) || metrics[0];

  return (
    <div className="w-full max-w-7xl mx-auto px-6 py-20 border-t border-[#E5E5E0] bg-stone-light" id="biomarkers">
      <div className="mb-14 grid grid-cols-1 md:grid-cols-2 gap-8 items-end">
        <div>
          <div className="mb-4 inline-flex items-center gap-2 text-[#C41E3A] font-bold tracking-[0.2em] text-[10px] uppercase">
            <span className="w-8 h-[2px] bg-[#C41E3A]"></span>
            DIAGNOSTICS // NEURAL INSIGHTS
          </div>
          <h2 className="text-3xl md:text-5xl font-display font-black tracking-tight text-[#0A0A0A] uppercase">
            Biomarkers & Insights
          </h2>
        </div>
        <p className="text-[#78716C] text-sm md:text-base leading-relaxed font-semibold max-w-xl">
          NeviSense telemetry tracks cognitive ergonomics. Our diagnostic hub quantifies performance, confirming lower navigational strain and hyper-acute landmark mapping over time.
        </p>
      </div>

      {/* Main Panel Frame */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Toggle Menu - Left Col (Col span 4) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          {metrics.map((metric) => {
            const isSelected = metric.id === selectedMetricId;
            return (
              <button
                key={metric.id}
                onClick={() => setSelectedMetricId(metric.id)}
                className={`w-full text-left p-6 rounded-none border-2 transition-all duration-300 relative overflow-hidden group ${
                  isSelected
                    ? 'bg-white border-[#C41E3A]'
                    : 'bg-white/50 border-black/5 hover:bg-white hover:border-[#A8A29E]'
                }`}
              >
                {/* Visual marker inside selected button */}
                {isSelected && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#C41E3A]"></div>
                )}
                
                <div className="flex justify-between items-start mb-3">
                  <span className={`text-xs font-mono tracking-widest uppercase transition-colors ${
                    isSelected ? 'text-[#C41E3A]' : 'text-[#78716C]'
                  }`}>
                    {metric.id === 'latency' ? 'SPEED' : metric.id === 'fatigue' ? 'COGNITIVE' : 'ACCURACY'}
                  </span>
                  
                  <span className={`w-2 h-2 rounded-none ${
                    metric.status === 'optimal' 
                      ? 'bg-emerald-500' 
                      : 'bg-[#C41E3A]'
                  }`}></span>
                </div>

                <h3 className="font-display font-bold uppercase text-lg text-[#0A0A0A] mb-1 group-hover:text-[#C41E3A] transition-colors">
                  {metric.name}
                </h3>

                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-3xl font-display font-bold text-[#0A0A0A]">
                    {metric.value}
                  </span>
                  <span className="text-sm font-mono text-[#78716C]">
                    {metric.unit}
                  </span>
                </div>

                <div className="text-[10px] font-mono text-[#78716C] mt-3 flex items-center gap-1.5 border-t border-[#FAFAF9] pt-2">
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                  <span className="truncate">{metric.trend}</span>
                </div>
              </button>
            );
          })}

          <div className="mt-2 bg-[#C41E3A]/5 border border-[#C41E3A]/10 rounded-none p-4 flex gap-3 text-xs text-[#911126]">
            <Brain className="w-5 h-5 text-[#C41E3A] shrink-0 mt-0.5" />
            <p className="leading-relaxed font-sans font-medium">
              Neuroplastic adaptation speeds double within 7 sessions. Safe, intuitive navigation pathways become secondary reflex loops.
            </p>
          </div>
        </div>

        {/* Dynamic Display Chart - Right Col (Col span 8) */}
        <div className="lg:col-span-8 bg-white border-2 border-[#0A0A0A]/10 rounded-none p-6 md:p-8 flex flex-col justify-between overflow-hidden relative min-h-[450px]">
          
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <span className="text-[10px] font-mono font-medium text-neutral-400">
              SIMULATING FEED:
            </span>
            <button 
              onClick={() => setIsSimulating(!isSimulating)}
              className={`p-1.5 rounded-none border transition-colors ${
                isSimulating ? 'bg-[#C41E3A]/10 border-[#C41E3A]/20 text-[#C41E3A]' : 'bg-[#FAFAF9] border-black/10 text-neutral-400'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin-slow' : ''}`} />
            </button>
          </div>

          <div className="max-w-xl">
            <span className="font-mono text-[9px] text-[#A8A29E] tracking-widest uppercase">
              METRIC OVERVIEW // SELECTED DATASTREAM
            </span>
            <h3 className="font-display font-bold uppercase text-2xl text-[#0A0A0A] mt-1 mb-2">
              {activeMetric.name}
            </h3>
            <p className="text-xs text-[#78716C] leading-relaxed font-sans mb-6">
              {activeMetric.description}
            </p>
          </div>

          {/* SVG Analytical Line Graph Frame */}
          <div className="relative w-full h-56 my-4 border-b border-l border-neutral-200 bg-[#FAFAF9]/50 rounded-none flex flex-col justify-between p-4">
            
            {/* Horizontal Grid lines */}
            <div className="absolute left-0 right-0 top-[25%] border-t border-dashed border-neutral-100 pointer-events-none"></div>
            <div className="absolute left-0 right-0 top-[50%] border-t border-dashed border-neutral-100 pointer-events-none"></div>
            <div className="absolute left-0 right-0 top-[75%] border-t border-dashed border-neutral-100 pointer-events-none"></div>

            {/* Render Curve Pathway */}
            <svg 
              className="absolute inset-0 w-full h-full p-4 pointer-events-none overflow-visible"
              viewBox="0 0 400 120"
              preserveAspectRatio="none"
            >
              {/* Pulse ripple line */}
              <path
                d={activeMetric.svgPath}
                fill="none"
                stroke="#C41E3A"
                strokeWidth="2.5"
                className="opacity-90 transition-all duration-700"
                strokeDasharray="400"
                strokeDashoffset={isSimulating ? jitter * 1.5 : 0}
              />
              {/* Highlight fill gradient */}
              <path
                d={`${activeMetric.svgPath} L400,120 L0,120 Z`}
                fill="url(#grad)"
                className="opacity-15 transition-all duration-700"
              />
              
              <defs>
                <linearGradient id="grad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#C41E3A" />
                  <stop offset="100%" stopColor="#FAFAF9" stopOpacity="0" />
                </linearGradient>
              </defs>
            </svg>

            {/* Chart point nodes markers (HTML positions over layout) */}
            <div className="absolute inset-0 flex justify-between items-end px-4 pb-2 z-10 select-none">
              {activeMetric.points.map((pt, i) => (
                <div key={i} className="flex flex-col items-center group/dot" style={{ width: '40px' }}>
                  <div className="opacity-0 group-hover/dot:opacity-100 transition-opacity bg-stone-dark text-white text-[9px] font-mono px-1.5 py-0.5 rounded-none mb-1 absolute bottom-[80%] font-semibold pointer-events-none">
                    {pt}{activeMetric.unit}
                  </div>
                  <div className="w-2.5 h-2.5 bg-white border-2 border-[#C41E3A] rounded-none group-hover/dot:scale-130 transition-transform"></div>
                  <span className="text-[9px] font-mono text-[#78716C] mt-2">
                    {activeMetric.labels[i]}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-t border-[#E5E5E0] pt-4 mt-4 text-[11px] font-mono text-[#78716C]">
            <div className="flex items-center gap-2">
              <Activity className="w-3.5 h-3.5 text-[#C41E3A] animate-pulse" />
              <span>SENSORY PROTOCOL SHIELD ACTIVE // COGNITIVE LABS CERTIFIED</span>
            </div>
            <div className="flex items-center gap-3">
              <span>94.8% TRUST QUOTIENT</span>
              <span>100% SECURE DATA ENVELOPE</span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
