'use client';

import React, { useEffect, useRef, useState } from 'react';
import { Rotate3d, Sparkles } from 'lucide-react';

interface Point3D {
  x: number;
  y: number;
  z: number;
  u: number;
  v: number;
  baseColor: string;
}

export default function MobiusSculpture() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Interactive rotation state controlled by mouse drag
  const [isDragging, setIsDragging] = useState(false);
  const mouseRef = useRef({ x: 0, y: 0, lastX: 0, lastY: 0 });
  const rotationRef = useRef({ x: 0.5, y: 0.8, targetX: 0.5, targetY: 0.8 });
  const [activeInteractions, setActiveInteractions] = useState<{ x: number, y: number, radius: number }[]>([]);
  const rippleRef = useRef<{ u: number; speed: number; progress: number }[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = canvas.width;
    let height = canvas.height;

    // Resize observer to scale perfectly
    const handleResize = () => {
      if (!containerRef.current || !canvas) return;
      const rect = containerRef.current.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      
      // Handle high DPI screens
      const dpr = window.devicePixelRatio || 1;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.scale(dpr, dpr);
      
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
    };

    const resizeObserver = new ResizeObserver(handleResize);
    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }
    handleResize();

    // Create Möbius ribbon points
    const points: Point3D[] = [];
    const countU = 140; // Resolution along the ribbon loop
    const countV = 16;  // Width resolution across the ribbon

    for (let i = 0; i < countU; i++) {
      const u = (i / countU) * Math.PI * 2;
      for (let j = 0; j < countV; j++) {
        // v ranges from -1 to 1
        const v = -1 + (j / (countV - 1)) * 2;
        
        // Color mapping based on ribbon coordinates
        const isEdge = j === 0 || j === countV - 1;
        const baseColor = isEdge ? '#C41E3A' : '#78716C'; // red edges, stone/slate inner

        points.push({
          x: 0,
          y: 0,
          z: 0,
          u,
          v,
          baseColor
        });
      }
    }

    // Interactive ripple wave
    const triggerRipple = () => {
      rippleRef.current.push({
        u: Math.random() * Math.PI * 2,
        speed: 0.05,
        progress: 0
      });
      if (rippleRef.current.length > 3) {
        rippleRef.current.shift();
      }
    };

    // Render loop
    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Smoothly interpolate rotation to targets
      rotationRef.current.x += (rotationRef.current.targetX - rotationRef.current.x) * 0.1;
      rotationRef.current.y += (rotationRef.current.targetY - rotationRef.current.y) * 0.1;

      // Slowly auto-rotate if not dragging
      if (!isDragging) {
        rotationRef.current.targetY += 0.003;
        rotationRef.current.targetX = 0.4 + Math.sin(Date.now() * 0.0005) * 0.15;
      }

      const rx = rotationRef.current.x;
      const ry = rotationRef.current.y;

      // Update ripple wave states
      rippleRef.current.forEach(rip => {
        rip.progress += rip.speed;
      });
      rippleRef.current = rippleRef.current.filter(rip => rip.progress < Math.PI);

      // Calculate 3D points, apply rotations and perspective projections
      const projectedPoints = points.map(pt => {
        // Math coordinates of a Möbius strip
        // R is the major radius
        const R = Math.min(width, height) * 0.32;
        const w = pt.v * (R * 0.28); // ribbon width width

        // 3D coordinates before rotation
        // Math formulations for Mobius
        const xVal = (R + w * Math.cos(pt.u / 2)) * Math.cos(pt.u);
        const yVal = (R + w * Math.cos(pt.u / 2)) * Math.sin(pt.u);
        const zVal = w * Math.sin(pt.u / 2);

        // Standard 3D rotations
        // Rotate around Y axis
        let x1 = xVal * Math.cos(ry) - zVal * Math.sin(ry);
        let z1 = xVal * Math.sin(ry) + zVal * Math.cos(ry);
        let y1 = yVal;

        // Rotate around X axis
        let x2 = x1;
        let y2 = y1 * Math.cos(rx) - z1 * Math.sin(rx);
        let z2 = y1 * Math.sin(rx) + z1 * Math.cos(rx);

        // Perspective projection parameters
        const distance = R * 3;
        const cameraZ = distance + z2;
        const scale = distance / cameraZ;

        // Project coordinate 2D
        const px = x2 * scale + width / 2;
        const py = y2 * scale + height / 2;

        // Calculate visual properties
        let finalColor = pt.baseColor;
        let pSize = scale * 1.6;

        // Special interaction styling: check ripples
        rippleRef.current.forEach(rip => {
          const dist = Math.abs(pt.u - rip.u);
          const influence = Math.max(0, Math.sin(rip.progress) - dist * 1.5);
          if (influence > 0) {
            finalColor = '#E73C56'; // bright red wave
            pSize += influence * 3.5;
          }
        });

        return {
          px,
          py,
          depth: z2,
          color: finalColor,
          size: pSize,
          opacity: Math.max(0.12, Math.min(1, scale * 0.95))
        };
      });

      // Painter's algorithm: sort points from back to front based on depth
      projectedPoints.sort((a, b) => b.depth - a.depth);

      // Draw projected points
      projectedPoints.forEach(pt => {
        ctx.beginPath();
        ctx.arc(pt.px, pt.py, pt.size, 0, Math.PI * 2);
        
        // Add elegant radial alpha decay
        ctx.globalAlpha = pt.opacity;
        ctx.fillStyle = pt.color;
        ctx.fill();
      });

      // Reset global alpha
      ctx.globalAlpha = 1.0;

      // Draw interactive indicator hint text in bottom corner
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    // Trigger random ripple pulse occasionally to make it feel alive
    const intervalId = setInterval(triggerRipple, 4500);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      clearInterval(intervalId);
    };
  }, [isDragging]);

  // Mouse handlers for custom dragging rotation
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    mouseRef.current.lastX = e.clientX;
    mouseRef.current.lastY = e.clientY;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const deltaX = e.clientX - mouseRef.current.lastX;
    const deltaY = e.clientY - mouseRef.current.lastY;

    rotationRef.current.targetY += deltaX * 0.007;
    rotationRef.current.targetX += deltaY * 0.007;

    mouseRef.current.lastX = e.clientX;
    mouseRef.current.lastY = e.clientY;
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const triggerSparklePress = () => {
    rippleRef.current.push({
      u: Math.random() * Math.PI * 2,
      speed: 0.08,
      progress: 0
    });
  };

  return (
    <div 
      ref={containerRef} 
      className="relative w-full h-[500px] flex items-center justify-center cursor-grab select-none active:cursor-grabbing group"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Decorative frame elements to establish Swiss editorial framing */}
      <div className="absolute top-4 left-4 border-l border-t border-[#E5E5E0] w-6 h-6 pointer-events-none transition-colors duration-300 group-hover:border-[#C41E3A]"></div>
      <div className="absolute top-4 right-4 border-r border-t border-[#E5E5E0] w-6 h-6 pointer-events-none transition-colors duration-300 group-hover:border-[#C41E3A]"></div>
      <div className="absolute bottom-4 left-4 border-l border-b border-[#E5E5E0] w-6 h-6 pointer-events-none transition-colors duration-300 group-hover:border-[#C41E3A]"></div>
      <div className="absolute bottom-4 right-4 border-r border-b border-[#E5E5E0] w-6 h-6 pointer-events-none transition-colors duration-300 group-hover:border-[#C41E3A]"></div>

      {/* Actual Drawing Stage Canvas */}
      <canvas 
        ref={canvasRef} 
        className="block"
      />

      {/* Floating high-tech overlay badge */}
      <div className="absolute bottom-6 flex items-center gap-4 bg-white/80 backdrop-blur-sm border border-[#E5E5E0] py-2 px-4 rounded-full text-xs font-mono text-[#78716C] shadow-sm select-none pointer-events-auto transition-transform hover:scale-102">
        <Rotate3d className="w-3.5 h-3.5 text-[#C41E3A] animate-spin-slow" />
        <span>INTERACTIVE CORE SCULPTURE</span>
        <button 
          onClick={(e) => { e.stopPropagation(); triggerSparklePress(); }}
          className="ml-2 pl-2 border-l border-[#E5E5E0] flex items-center gap-1 text-[#C41E3A] hover:opacity-80 active:scale-95 focus:outline-none"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>pulse</span>
        </button>
      </div>

      <div className="absolute top-6 right-6 font-mono text-[10px] tracking-wider text-neutral-400 opacity-60 group-hover:opacity-100 transition-opacity">
        SYSTEM ACTIVE: 60FPS
      </div>
    </div>
  );
}
