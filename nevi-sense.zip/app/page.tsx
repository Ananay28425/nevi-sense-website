'use client';

import React, { useState, useEffect } from "react";
import LoadingScreen from "@/components/nevisense/LoadingScreen";
import Navbar from "@/components/nevisense/Navbar";
import HeroSection from "@/components/nevisense/HeroSection";
import {
  ChallengeSection,
  IndependenceSection,
} from "@/components/nevisense/ContentSections";
import {
  FinalSection,
} from "@/components/nevisense/FinalSections";

export default function Home() {
  const [loaded, setLoaded] = useState(false);
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const onScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div style={{ backgroundColor: "#FAFAF9", minHeight: "100vh", overflowX: "hidden" }}>
      <LoadingScreen onComplete={() => setLoaded(true)} />

      <div
         style={{
          opacity: loaded ? 1 : 0,
          transition: "opacity 0.8s ease",
          backgroundColor: "#FAFAF9",
        }}
      >
        <Navbar />
        <HeroSection scrollY={scrollY} />
        <ChallengeSection />
        <IndependenceSection />
        <FinalSection />
      </div>
    </div>
  );
}
