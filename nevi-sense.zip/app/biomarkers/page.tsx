"use client";

import React from "react";
import Navbar from "@/components/nevisense/Navbar";
import {
  BiomarkersSection,
  HealthInsightsSection,
} from "@/components/nevisense/ContentSections";
import { FinalSection } from "@/components/nevisense/FinalSections";

export default function BiomarkersPage() {
  return (
    <div style={{ backgroundColor: "#080808", minHeight: "100vh", overflowX: "hidden" }}>
      <div
        style={{
          backgroundColor: "#080808",
        }}
      >
        <Navbar />
        {/* Dark Top Spacer for fixed navbar */}
        <div style={{ height: "100px", backgroundColor: "#080808" }} />
        
        {/* Biomarkers content sections */}
        <BiomarkersSection />
        <HealthInsightsSection />
        
        {/* shared footer and CTA */}
        <FinalSection />
      </div>
    </div>
  );
}
