"use client";

import React from "react";
import Navbar from "@/components/nevisense/Navbar";
import {
  WhatItDoesSection,
  BeyondNavigationSection,
  WhoItServesSection,
} from "@/components/nevisense/ContentSections";
import { FinalSection } from "@/components/nevisense/FinalSections";

export default function PlatformPage() {
  return (
    <div style={{ backgroundColor: "#0A0A0A", minHeight: "100vh", overflowX: "hidden" }}>
      <div
        style={{
          backgroundColor: "#0A0A0A",
        }}
      >
        <Navbar />
        {/* Dark Top Spacer for fixed navbar */}
        <div style={{ height: "100px", backgroundColor: "#0A0A0A" }} />
        
        {/* Platform capability sections */}
        <WhatItDoesSection />
        <BeyondNavigationSection />
        <WhoItServesSection />
        
        {/* shared footer and CTA */}
        <FinalSection />
      </div>
    </div>
  );
}
