"use client";

import React from "react";
import Navbar from "@/components/nevisense/Navbar";
import { AboutSection } from "@/components/nevisense/ContentSections";
import { VisionSection, FinalSection } from "@/components/nevisense/FinalSections";

export default function AboutPage() {
  return (
    <div style={{ backgroundColor: "#FAFAF9", minHeight: "100vh", overflowX: "hidden" }}>
      <div
        style={{
          backgroundColor: "#FAFAF9",
        }}
      >
        <Navbar />
        {/* Editorial Top Spacer for fixed navbar */}
        <div style={{ height: "120px", backgroundColor: "#FAFAF9" }} />
        
        {/* Core content */}
        <AboutSection />
        <VisionSection />
        
        {/* Footer and final call to action */}
        <FinalSection />
      </div>
    </div>
  );
}
