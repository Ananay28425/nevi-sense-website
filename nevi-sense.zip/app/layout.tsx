import type {Metadata} from 'next';
import { Inter, Space_Grotesk } from 'next/font/google';
import './globals.css'; // Global styles

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
});

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-display',
});

export const metadata: Metadata = {
  title: 'Nevi Sense — Reimagining Independence through Sensory AI',
  description: 'Nevi Sense is a sensory translation platform that empowers visually impaired individuals with real-time spatial awareness, intelligent cognitive navigation, and diagnostic sensory biomarkers.',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${inter.variable} ${spaceGrotesk.variable}`}>
      <body className="bg-[#FAFAF9] text-[#0A0A0A] font-sans antialiased selection:bg-[#C41E3A] selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
