"use client";

import React from "react";
import Navbar from "@/components/nevisense/Navbar";
import { InvestorSection, FinalSection } from "@/components/nevisense/FinalSections";

export default function InvestorsPage() {
  return (
    <div style={{ backgroundColor: "#000000", minHeight: "100vh", overflowX: "hidden" }}>
      <div
        style={{
          backgroundColor: "#000000",
        }}
      >
        <Navbar />
        {/* Dark Top Spacer for fixed navbar */}
        <div style={{ height: "100px", backgroundColor: "#000000" }} />
        
        {/* Investor content section */}
        <InvestorSection />
        
        {/* shared footer and CTA */}
        <FinalSection />
      </div>
    </div>
  );
}
